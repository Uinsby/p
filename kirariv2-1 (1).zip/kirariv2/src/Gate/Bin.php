<?php

namespace App\Gate;

use App\Config\StringUtils;
use App\Db\Query;

class Bin
{

    /**
     * Validar la estrutura del bin
     */
    private static function Validate(string | int $bin): array
    {

        $bin = substr(StringUtils::RemoveStrings($bin), 0, 6);
        if (strlen($bin) < 6) {
            return ['error' => 'Invalid bin length', 'code' => 'bin_too_short', 'ok' => false, 'bin' => $bin];
        } elseif (in_array($bin[0], [0])) {
            return ['error' => 'Invalid bin', 'code' => 'invalid_bin', 'ok' => false, 'bin' => $bin];
        } else {
            return ['ok' => true, 'bin' => $bin];
        }
    }

    /**
     * Validar y buscar un bin en la DB
     */
    public static function Get(string | int $bin): array
    {

        $fim = self::Validate($bin);

        if (!$fim['ok']) {
            return $fim;
        }

        $data = Query::Sql("SELECT * FROM bins WHERE bin = :numbr", [':numbr' => $fim['bin']]);
        if ($data['ok'] && $data['afectRow'] >= 1) {
            $fim = $data['datas'];
            $fim['ok'] = true;
            $fim['code'] = (bool) $fim['code'];
            $fim['error'] = 'Valid Bin';
            $fim['banned'] = (bool) $fim['banned'];
            $fim['vbv_msc'] = (bool) $fim['vbv_msc'];
            return $fim;
        } else {
            return ['error' => 'Bin not found', 'code' => 'bin_not_found', 'bin' => $bin, 'ok' => false];
        }
    }

    /**
     * Paginación para las extras
     */
    private static function Pagination(int $page = 0, int $sum = 45) {
        return $sum * $page;
    }

    /**
     * Obtener extras de un bin y devuelve un array dividiendo las extras en partes de 45
     */
    public static function Extras(string | int $bin, string $page = '0', string $part = '45'): array
    {
        $fim = self::Validate($bin);
        if (!$fim['ok']) {
            return $fim;
        }
        if (strpos(' '.$page, '-')) {
            return ['error' => 'No extras found', 'code' => 'no_extras', 'ok' => false, 'bin' => $fim['bin']];
        }
        $page = self::Pagination($page, $part);
        $datas = Query::GetAllRows("SELECT * FROM `extras` WHERE `bin` = :numbr ORDER BY `year` ASC LIMIT $page, $part", [':numbr' => $fim['bin']]);

        if (!$datas['ok']) {
            return ['error' => 'No extras found', 'code' => 'no_extras', 'ok' => false, 'bin' => $fim['bin']];
        }

        $cc = [];
        foreach ($datas['rows'] as $extras) {
            $cc[] = trim($extras['cc'] . '|' . $extras['month'] . '|' . $extras['year'] . '|' . $extras['cvv']);
        }
        return [
            'ok' => true,
            'error' => 'Extras found',
            'bin' => $fim['bin'],
            'total' => $datas['count'],
            'parts' => count($cc),
            'extras' => $cc,
        ];
    }

    /**
     * Banear/Desbanear un bin
     * 
     */
    public static function BanUnban(string|int $bin, bool $status = false)
    {
        $val = self::Validate($bin);
        if (!$val['ok']) return $val;

        $query = "UPDATE bins SET banned = :status WHERE bin = :bin";
        return Query::Sql($query, [':status' => $status, ':bin' => $val['bin']]);
    }
}
