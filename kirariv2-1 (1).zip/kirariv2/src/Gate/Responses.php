<?php
namespace App\Gate;

class Responses {
    
    /** All page response */
    private static string $str = '';
    /** First response */
    public static string $res = '';
    /** Second response */
    public static string $code = '';
    /** AVS response */
    public static string $avs = '';
    /** CVV response */
    public static string $cvv = '';
    /** RISK CODE response */
    public static string $risk = '';

    /**
     * Dar Formanto al cvv y avs
     */
    public static function ParseCvvAvs(?string $cv = null, ?string $av = null, ?string $rsk = null):string|null
    {
        self::$cvv = $cv ?? self::$cvv;
        self::$avs = $av ?? self::$avs;
        self::$risk = $rsk ?? self::$risk;
        
        $res = '';
        
        if (self::$cvv && !empty(self::$cvv)) $res .= '<b><u>CVV:</u> [<i>' . self::$cvv . '</i>]</b>';
        if (self::$avs && !empty(self::$avs)) $res .= '  <b><u>AVS:</u> [<i>' . self::$avs . '</i>]</b>';
        if (self::$risk && !empty(self::$risk)) $res .= '  <b><u>RISK:</u> [<i>' . self::$risk . '</i>]</b>';

        $res = trim($res);
        $res = str_replace('  ', ' | ', $res);
        if (empty($res)) return null;
        return $res;
    }

    /**
     * Establecer los parametros de la respuesta
     *
     * @param string|null $response Response 1, res
     * @param string|null $result Response 2, code
     * @param string|null $avs AVS code
     * @param string|null $cvv CVV code
     * @param string|null $body al body page
     */
    public static function SetParams(?string $response = null, ?string $result = null, ?string $avs = null, ?string $cvv = null, ?string $body = null):void
    {
        self::$str  = @urldecode(@trim($body)) ?? 'Null';
        self::$res  = @urldecode(@trim($response)) ?? 'Null';
        self::$code = @urldecode(@trim($result)) ?? 'Null';
        self::$avs  = @trim($avs) ?? 'Null';
        self::$cvv  = @trim($cvv) ?? 'Null';
    }

    /**
     * Get emoji from response
     */
    private static function Emoji(bool $live, bool $error):string
    {
        return $error ? '⚠️' : ($live ? '✅' : '❌');
    }

    /**
     * Show result array
     *
     * @param boolean $live True si es una live, si es true tambien se guarda la live
     * @param string $status Approved, Declined, Error, Etc
     * @param string $response Card response explained
     * @param string|null $car_code AVS and CVV code
     * @param integer $discount Credits discount
     */
    private static function Parser(bool $live = false, string $status = null, string $response = null, ?string $car_code = null, int|float $discount = 0, bool $error = false):array
    {
        return [
            'live' => $live,
            'emoji' => self::Emoji($live, $error),
            'status' => $status,
            'content' => $response,
            'card_code' => $car_code,
            'discount' => $discount
        ];
    }

    /**
     * Responses for bluepay
     */
    public static function Bluepay():array
    {
        if (self::$res == 'APPROVED' && self::$cvv == 'M') return self::Parser(true, 'Approved', 'CVV match', self::ParseCvvAvs(), 2);
        if (self::$res == 'APPROVED' && self::$cvv == 'N') return self::Parser(true, 'Approved', 'CCN live', self::ParseCvvAvs(), 1);
        if (self::$res == 'CVV2 DECLINED' || self::$code == 'CVV2 DECLINED') return self::Parser(true, 'Approved', 'CVV2 DECLINED', self::ParseCvvAvs(), 1);
        if (self::$res == 'INV CVV2 MATCH' || self::$code == 'INV CVV2 MATCH') return self::Parser(true, 'Approved', 'INV CVV2 MATCH', self::ParseCvvAvs(), 1);
        if (self::$avs == 'X') return self::Parser(true, 'Live avs', 'ADDER ZIP EXACT MATCH', self::ParseCvvAvs(), 1);
        if (self::$res == 'INVALID CARD' || self::$res == 'INV ACCT NUM') return self::Parser(false, 'Declined', 'Invalid Card', self::ParseCvvAvs());
        if (self::$res == 'FS DECLINE' || self::$code == 'FS DECLINE') return self::Parser(false, 'Declined', 'Fraud detected', self::ParseCvvAvs());
        if (self::$res == 'EXPIRED CARD') return self::Parser(false, 'Declined', 'Expired Card', self::ParseCvvAvs());
        if (self::$res == 'DECLINED' || self::$code == 'DECLINED') return self::Parser(false, 'Declined', self::$code, self::ParseCvvAvs());
        return self::Parser(false, 'Error', self::$code, self::ParseCvvAvs(), 0, true);
    }

    /**
     * Responses for vbv braintree
     */
    public static function VbvBr():array
    {
        switch (self::$res) {
            case 'authenticate_attempt_successful':
                return self::Parser(true, '3D FALSE ['.self::$code.']', 'Authenticate Attempt Successful', null, 1); break;
            case 'lookup_not_enrolled':
                return self::Parser(true, '3D FALSE ['.self::$code.']', 'Lookup Not Enrolled', null, 1); break;
            case 'lookup_enrolled':
                return self::Parser(false, '3D TRUE ['.self::$code.']', 'Lookup Enrolled'); break;
            case 'lookup_error':
                return self::Parser(false, '3D TRUE ['.self::$code.']', 'Lookup Error'); break;
            case 'unsupported_card':
                return self::Parser(false, 'Unsupported Card', 'Card not supported'); break;
            case 'authentication_unavailable':
                return self::Parser(false, 'Unavailable['.self::$code.']', 'Authentication Unavailable'); break;
            default:
                return self::Parser(false, 'Unknown Error', 'Try again', null, 0, true); break;
        }
    }

    /**
     * Responses for convergepay
     */
    public static function Cpay(string $charge = '$10.00'):array
    {
        if (strpos(self::$str, 'Exp Date Invalid') || strpos(self::$str, 'Credit Card Number Invalid')) {
            return self::Parser(false, 'Declined', 'Credit Card Invalid');
        } elseif (self::$res == 'APPROVAL') {
            return self::Parser(true, self::$res, 'Charged '.$charge, self::ParseCvvAvs(), 2);
        } elseif (self::$res == 'DECLINED CVV2') {
            return self::Parser(true, 'Verified', self::$res, self::ParseCvvAvs(), 1);
        } elseif (self::$res == 'DECLINED: NSF') {
            return self::Parser(true, 'Verified', 'Insufficient funds ['.$charge.']', self::ParseCvvAvs(), 0.5);
        } elseif (self::$res == 'INVALID CARD' || self::$code == 'INVALID CARD') {
            return self::Parser(false, 'Declined', 'INVALID CARD', self::ParseCvvAvs());
        } elseif (self::$res == 'PICK UP CARD') {
            return self::Parser(false, 'Declined', self::$res, self::ParseCvvAvs());
        } elseif (self::$cvv == 'P') {
            return self::Parser(false, 'Declined', self::$res, self::ParseCvvAvs());
        } elseif (self::$cvv == 'U') {
            return self::Parser(false, 'Declined', 'Issuer no certified', self::ParseCvvAvs());
        } elseif (self::$cvv == 'S') {
            return self::Parser(false, 'Declined', 'Invalid CVV', self::ParseCvvAvs());
        } elseif (self::$res == 'DENIED') {
            return self::Parser(false, 'Declined', 'Invalid Card', self::ParseCvvAvs());
        } elseif (self::$res == 'DO NOT HONOR') {
            return self::Parser(false, 'Declined', self::$res, self::ParseCvvAvs());
        } elseif (self::$cvv == 'M' && self::$res != 'DECLINED') {
            return self::Parser(true, 'Verified', 'CVV MATCH ['.self::$res.']', self::ParseCvvAvs(), 0.5);
        } elseif (self::$res == 'DECLINED 79') {
            return self::Parser(false, 'Declined', self::$res, self::ParseCvvAvs());
        } else {
            return self::Parser(false, 'Declined', self::$res, self::ParseCvvAvs(), 0, true);
        }
    }

    /**
     * Responses for Authorize.net Charge
     */
    public static function authnetch(string $charge = '$0.01'):array
    {   

        $res_decode = json_decode(self::$res, true);
        if ($res_decode['msg']['responseCode'] == 2 xor '2' && $res_decode['msg']['errors']['errors']['error'][0]['errorText'] == 'This transaction has been declined.') {
            return self::Parser(false, 'Declined', '2 - This transaction has been declined.', self::ParseCvvAvs());
        } elseif ($res_decode['msg']['responseCode'] == 4 xor '4' && $res_decode['msg']['errors']['errors']['error'][0]['errorText'] == 'This transaction has been declined.') {
            return self::Parser(false, 'Declined', '4 - This transaction has been declined.', self::ParseCvvAvs());
        } elseif ($res_decode['status'][0]['code'] == 1 xor '1' && $res_decode['description'] == 'This transaction has been approved.') {
            return self::Parser(true, 'Declined', 'Charged'.$charge, null, 2);
        } else {
            return self::Parser(false, 'Unknown Error', htmlentities(self::$res), null, 0, true);
        }
    }

    /**
     * Responses for sagepayment gateway
     */
    public static function Sagepay(?string $riskCode = ''):array 
    {
        self::$risk = $riskCode;

        if (self::$res == 'APPROVED') {
            return self::Parser(true, self::$res, 'Transaction approved', self::ParseCvvAvs(), 1);
        } elseif (self::$res == 'CVV2 MISMATCH' || self::$res == 'CVV2 MATCH' || self::$res == 'INVALID CVV2') {
            return self::Parser(true, 'Verified', self::$res, self::ParseCvvAvs(), 1);
        } elseif (self::$res == 'AVS FAILURE' || strpos(self::$str, 'AVS FAILURE')) {
            return self::Parser(false, 'Live', 'AVS FAILURE', self::ParseCvvAvs(), 0.5);
        } elseif (self::$res == 'INVALID CARD') {
            return self::Parser(false, 'Declined', self::$res, self::ParseCvvAvs());
        } elseif (self::$res == 'EXPIRED CARD') {
            return self::Parser(false, 'Declined', self::$res, self::ParseCvvAvs());
        } elseif(self::$res == 'SUSPECTED FRAUD') {
            return self::Parser(false, 'Declined', self::$res, self::ParseCvvAvs());
        } elseif (self::$res == 'DECLINED' || self::$res == 'DECLINE') {
            return self::Parser(false, 'Declined', self::$res, self::ParseCvvAvs());
        } else {
            return self::Parser(false, 'Declined', self::$res, self::ParseCvvAvs(), 0, true);
        }
    }

    /**
     * Responses for cardinal commerse 3d
     */
    public static function cardinal():array 
    {
        if (self::$res == false) {
            return self::Parser(true, "3D FALSE", 'Authentication Bypassed', null, 1);
        } elseif (self::$res == true) {
            return self::Parser(false, '3D TRUE', 'Authentication Fail', null, 0);
        } else {
            return self::Parser(false, 'Unknown Error', self::$res, null, 0, true);
        }
    }

    /**
     * Responses for Authorize.net CCN Charge
     */
    public static function authnetccn():array 
    {
        if (self::$res == "The transaction has been declined because of an AVS mismatch. The address provided does not match billing address of cardholder.") {
            return self::Parser(true, "Approved", 'No Charged[AVS FAIL]', null, 0);
        } elseif (strpos("This transaction has been declined.", self::$res)) {
            return self::Parser(false, 'Declined', 'This transaction has been declined', null, 0);
        } elseif (strpos("This transaction has been declined.", self::$str) || strpos("This transaction has been declined.", self::$str)) {
            return self::Parser(false, 'Declined', 'This transaction has been declined', null, 0);
        } elseif (strpos("Thank you for your order", self::$str)) {
            return self::Parser(false, 'Approved', 'Charged $1', null, 0);
        } else {
            return self::Parser(false, 'Unknown Error', self::$str, null, 0, true);
        }
    }

    /**
     * Responses for Unknown Gateway CCN Charge
     */
    public static function unkccnc():array 
    {
        if (self::$res == "Credit Card Decline: The billing zip code provided does not match the information on file with the cardholder's bank." || self::$res == "Credit Card Decline: Please contact card-issuing bank, they received the billing zip code but did not verify whether it was correct.") {
            return self::Parser(false, "Unknown", 'AVS No Match', null, 0, true);
        } elseif (self::$res == "Credit Card Decline: Do Not Honor") {
            return self::Parser(false, 'Declined', 'Do Not Honor', null, 0);
        } elseif (self::$res == "Credit Card Decline: Limit Exceeded") {
            return self::Parser(false, 'Declined', 'Limit Exceeded', null, 0);
        } elseif (self::$res == "Credit Card Decline: Transaction Not Allowed") {
            return self::Parser(false, 'Declined', 'Transaction Not Allowed', null, 0);
        } elseif (self::$res == "Credit Card Decline: Declined - Call Issuer") {
            return self::Parser(false, 'Declined', 'Declined - Call Issuer', null, 0);
        } elseif (strpos("transaction_id", self::$res)) {
            return self::Parser(true, 'Approved', 'Charged $118.00', null, 1);
        } elseif (self::$res == "Credit Card Decline: Insufficient Funds") {
            return self::Parser(true, 'Approved', 'Insufficient Funds', null, 1);
        } else {
            return self::Parser(false, 'Unknown Error', self::$res, null, 0, true);
        }
    }

/**
     * Responses for Stan Adyen AUth
     */
    public static function StanAd():array 
    {
        if (self::$res == '{"errors":[{"code":"Streamco.Billing.InvalidCardDetails","dialogTitle":"Sorry, the card details entered are incorrect.","messageTemplate":"Please check the details entered and try again."}]}') {
            return self::Parser(false, "Declined", 'Invalid Card Details', null, 0);
        } elseif (self::$res == '{"errors":[{"code":"Streamco.Billing.BlockedCard","dialogTitle":"Sorry, your card cannot be used.","messageTemplate":"Please use a different card, or try again later. If the problem persists, please contact your bank or customer support."}]}') {
            return self::Parser(false, 'Declined', 'Card Blocked', null, 0);
        } elseif (self::$res == '{"errors":[{"code":"Streamco.Billing.AussieAussieAussie"}]}') {
            return self::Parser(false, 'Declined', 'Card Not Supported', null, 0);
        } elseif (self::$res == "Credit Card Decline: Transaction Not Allowed") {
            return self::Parser(false, 'Declined', 'Transaction Not Allowed', null, 0);
        } elseif (self::$res == "Credit Card Decline: Declined - Call Issuer") {
            return self::Parser(false, 'Declined', 'Declined - Call Issuer', null, 0);
        } elseif (self::$str == "204" || self::$str == "202") {
            return self::Parser(true, 'Approved', 'Card Authorized', null, 1);
        } elseif (self::$res == "Credit Card Decline: Insufficient Funds") {
            return self::Parser(true, 'Approved', 'Insufficient Funds', null, 1);
        } else {
            return self::Parser(false, 'Unknown Error', self::$res, null, 0, true);
        }
    }

/**
     * Responses for Vindicia Auth Responses
     */
    public static function unkauth():array 
    {
          if (strpos(self::$res, 'Unable to authorize the card')) {
            return self::Parser(false, "Declined", 'Unable to authorize the card', null, 0);
        } elseif (strpos(self::$res, '"object": "PaymentMethod"')) {
            return self::Parser(true, 'Approved', 'Card Authorized', null, 1);
        } else {
            return self::Parser(false, 'Unknown Error', self::$res, null, 0, true);
        }
    }


/**
     * Responses for Braintree Charge Responses
     */
    public static function brch():array 
    {
          if (self::$res == "(2014) - There was a problem processing your credit card, please double check your data and try again.") {
            return self::Parser(false, "Declined", '2014 - Fraud Suspected', null, 0);
        } elseif (self::$res == "(2044) - There was a problem processing your credit card, please double check your data and try again.") {
            return self::Parser(false, 'Declined', '2044 - Call Issuer', null, 0);
        } elseif (self::$res == "(2047) - There was a problem processing your credit card, please double check your data and try again.") {
            return self::Parser(false, 'Declined', '2047 - Call Issuer. Pick Up Card', null, 0);
        } elseif (self::$res == "(2046) - There was a problem processing your credit card, please double check your data and try again.") {
            return self::Parser(false, 'Declined', '2046 - Declined', null, 0);
        } elseif (self::$res == "(2007) - There was a problem processing your credit card, please double check your data and try again.") {
            return self::Parser(false, 'Declined', '2007 - No Account', null, 0);
        } elseif (self::$res == "(2000) - There was a problem processing your credit card, please double check your data and try again.") {
            return self::Parser(false, 'Declined', '2000 - Do Not Honor', null, 0);
        } elseif (strpos(self::$str, 'Thank you for the donation') || self::$res == '(1000) - There was a problem processing your credit card, please double check your data and try again.') {
            return self::Parser(true, 'Approved', 'Charged $1.00', null, 1);
        } else {
            return self::Parser(false, 'Unknown Error', self::$res, null, 0, true);
        }
    }

/**
     * Responses for Unknown Charge $5.00
     */
    public static function idk2(string $charge = '$5.00'):array 
    {
        if (strpos(self::$res, 'Error processing payment: CVV2 Mismatch')) {
            return self::Parser(true, "Approved", 'CVV2 Mismatch', null, 1);
        } elseif (strpos(self::$res, 'Error processing payment: Insufficient funds available')) {
            return self::Parser(true, "Approved", 'Insufficient Funds Available', null, 1);
        } elseif (strpos(self::$res, 'Error processing payment: Referral')) {
            return self::Parser(false, 'Declined', 'Referral', null, 0);
        } elseif (strpos(self::$res, 'Error processing payment: Declined')) {
            return self::Parser(false, 'Declined', 'Declined', null, 0);
        } elseif (strpos(self::$res, 'Error processing payment: Invalid account number')) {
            return self::Parser(false, 'Declined', 'Invalid account number', null, 0);
        } else {
            return self::Parser(false, 'Unknown Error', 'Try again', null, 0, true);
        }
    }
    /**
     * Responses for UsaePay AVS
     */
    public static function avs():array 
    {
        if (self::$res == "Address: No Match & 5 Digit Zip: No Match") {
            return self::Parser(false, "AVS Fail", 'Address: No Match & 5 Digit Zip: No Match ['.self::$avs.']', null, 0);
        } elseif (self::$res == "Global Non-AVS participant") {
            return self::Parser(true, 'Non AVS', 'Global Non-AVS Participant ['.self::$avs.']', null, 1);
        } elseif (self::$res == "Retry / System Unavailable") {
            return self::Parser(true, 'Non AVS', 'System Unavailable ['.self::$avs.']', null, 1);
        } elseif (self::$res == "Service Not Supported") {
            return self::Parser(true, 'Non AVS', 'Service Not Supported ['.self::$avs.']', null, 1);
        } else {
            return self::Parser(false, 'Unknown Error', self::$res, null, 0, true);
        }
    }

    /**
     * Responses for BlackBaud Charge
     */
    public static function blackbaud_ch():array 
    {
        if (strpos(self::$res, 'Transaction declined')) {
            return self::Parser(false, "Declined", 'Transaction Declined', null, 0);
        } elseif (strpos(self::$res, 'TransactionApproved')) {
            return self::Parser(true, 'Approved', 'Charged $5.00', null, 2);
        } elseif (strpos(self::$res, 'The Card Security Code does not match')) {
            return self::Parser(true, 'Approved', 'The Card Security Code does not match', null, 1);
        } elseif (strpos(self::$res, 'Unable to process transaction')) {
            return self::Parser(false, 'Declined', 'Unable to process transaction.', null, 0);
        } elseif (strpos(self::$res, 'Transaction not supported by institution')) {
            return self::Parser(false, 'Declined', 'Transaction not supported by institution.', null, 0);
        } elseif (strpos(self::$res, 'General decline code')) {
            return self::Parser(false, 'Declined', 'General Decline', null, 0);
        } elseif (strpos(self::$res, 'Multiple attempts at using this credit card') || strpos(self::$res, 'High risk of fraud determined for this transaction.')) {
            return self::Parser(false, 'Declined', 'Fraud', null, 0);
        } elseif (strpos(self::$res, 'Invalid charge card number')) {
            return self::Parser(false, 'Declined', 'Invalid card number', null, 0);
        } else {
            return self::Parser(false, 'Unknown Error', "Try Again", null, 0, true);
        }
    }
    /**
     * Responses for Paypal
     */
    public static function paypal():array 
    {
        if (strpos(self::$res, 'success')) {
            return self::Parser(true, "Approved", 'Card Authorized', null, 1);
        } elseif (strpos(self::$res, '{"field":"cvv","issue":"INVALID"}')) {
            return self::Parser(true, 'Approved', 'CVV INVALID', null, 1);
        } elseif (strpos(self::$res, 'EXISTING_ACCOUNT_RESTRICTED')) {
            return self::Parser(true, 'Approved', 'Existing Account Restricted', null, 1);
        } elseif (strpos(self::$res, 'ADD_CARD_CONTINGENCY')) {
            return self::Parser(false, 'Declined', 'Add Card Contingency', null, 0);
        } elseif (strpos(self::$res, '{"field":"expiration_time","issue":"INVALID"}')) {
            return self::Parser(false, 'Declined', 'Expired Card', null, 0);
        } elseif (strpos(self::$res, 'RATE_LIMIT_REACHED')) {
            return self::Parser(false, 'Rate Limit Reached', 'Try Again', null, 0, true);
        } elseif (self::$res == 'Empty Req 1 Token') {
            return self::Parser(false, 'Gate Error', 'Empty Token 1', null, 0, true);
        } elseif (self::$res == 'Empty Req 2 Token') {
            return self::Parser(false, 'Gate Error', 'Empty Token 2', null, 0, true);
        } elseif (self::$res == 'Req 3 Error') {
            return self::Parser(false, 'Gate Error', 'Error In Request 3', null, 0, true);
        } else {
            return self::Parser(false, 'Unknown Error', self::$res, null, 0, true);
        }
    }
    /**
     * Responses for payflow cvv avs
     */
    public static function PayFlow(string $charge = '$10.00'):array
    {
        if (self::$res == 'NO REASN TO DECL' && self::$code == 'Verified') {
            return self::Parser(true, 'Verified', 'No reason to declined', self::ParseCvvAvs(), 1);
        } elseif (self::$res == 'CVV2 DECLINED' || self::$res == 'CVCCVV2') {
            return self::Parser(true, 'Verified', 'CVV2 DECLINED', self::ParseCvvAvs(), 1);
        } elseif (self::$res == 'INV ACCT NUM' || self::$code == 'Invalid account number') {
            return self::Parser(false, 'Declined', 'Invalid card', self::ParseCvvAvs());
        } elseif (self::$res == 'SERV NOT ALLOWED') {
            return self::Parser(false, 'Declined', 'SERV NOT ALLOWED', self::ParseCvvAvs());
        } elseif (self::$res == 'EXPIRED CARD' || self::$code == 'Invalid expiration date') {
            return self::Parser(false, 'Declined', 'Expired card', self::ParseCvvAvs());
        } elseif (self::$cvv == 'M' && self::$res != 'DECLINED') {
            return self::Parser(true, 'Verified', 'CVV MATCH ['.self::$res.']', self::ParseCvvAvs(), 0.5);
        } elseif (self::$res != 'DECLINED' && self::$cvv == 'N') {
            return self::Parser(true, 'Verified', 'CCN MATCH ['.self::$res.']', self::ParseCvvAvs(), 0.5);
        } elseif (self::$avs == 'X') {
            return self::Parser(true, 'Live', 'ADDER ZIP EXACT MATCH', self::ParseCvvAvs(), 0.5);
        } elseif (self::$cvv == 'P') {
            return self::Parser(true, 'Live', 'Do not honor', self::ParseCvvAvs(), 0.5);
        } else {
            return self::Parser(false, 'Declined', self::$res, self::ParseCvvAvs(), 0, true);
        }
    }
    /**
     * Responses for stripe intent, auth
     */
    public static function Stripe():array
    {

        if (strpos(self::$res, 'fraudulent') || strpos(self::$str, 'fraudulent')) {
            return self::Parser(false, 'Declined', 'Fraudulent');
        } elseif (strpos(self::$res, 'Invalid account') || strpos(self::$res, 'invalid_account') || strpos(self::$str, 'Invalid account') || strpos(self::$str, 'invalid_account')) {
            return self::Parser(false, 'Declined', 'Invalid Account');
        } elseif (strpos(self::$res, 'security code is incorrect') || strpos(self::$res, 'incorrect_cvc') || strpos(self::$str, 'security code is incorrect') || strpos(self::$str, "incorrect_cvc")) {
            return self::Parser(true, 'Approved', 'Incorrect CVC', null, 1);
        } elseif (strpos(self::$res, 'incorrect_zip') || strpos(self::$str, '"incorrect_zip')) {
            return self::Parser(true, 'Approved', 'AVS Fail', null, 1);
        } elseif (strpos(self::$str, '"cvc_check": "pass"') || strpos(self::$res, 'Thank You For Donation') || strpos(self::$res, '"cvc_check":"pass"') || strpos(self::$res, 'Thank You')) {
            return self::Parser(true, 'Approved', 'Thank You For Donation', null, 1);
        } elseif (strpos(self::$res, '"valid": true') || strpos(self::$res, 'stripe_payment_setup_intent_id') || strpos(self::$res, '"status":-2,')) {
            return self::Parser(true, 'Approved', 'Card Authorized', null, 1);
        } elseif (strpos(self::$res, '"status": "succeeded"') || strpos(self::$res, '"status": "complete"')) {
            return self::Parser(true, 'Approved', 'Succeeded', null, 1);
        } elseif (strpos(self::$res, '"success":true,"') || strpos(self::$res, 'authentication_required')) {
            return self::Parser(true, 'Approved', 'CVV pass', null, 1);
        } elseif (strpos(self::$res, '"address_zip_check":"fail"') && strpos(self::$res, '"cvc_check":"pass"') || strpos(self::$str, '"address_zip_check":"fail"') && strpos(self::$str, '"cvc_check":"pass"')) {
            return self::Parser(true, 'Approved', 'CVV Pass [AVS fail]', null, 1);
        } elseif (strpos(self::$res, 'CardPaymentConfirmed') || strpos(self::$res, 'confirmCardPayment')) {
            return self::Parser(true, 'Approved', 'Card Payment Confirmed', null, 1);
        } elseif (strpos(self::$res, 'Your card has insufficient funds') || strpos(self::$res, 'insufficient_funds')|| strpos(self::$str, 'insufficient_funds')) {
            return self::Parser(true, 'Approved', 'Your card has insufficient funds', null, 1);
        } elseif (strpos(self::$res, '"type": "intent_confirmation_challenge"') || strpos(self::$str, '"type": "intent_confirmation_challenge"')) {
            return self::Parser(false, 'Error', 'Captcha Required');
        } elseif (strpos(self::$res, 'card_error_authentication_required') || strpos(self::$str, 'card_error_authentication_required')) {
            return self::Parser(false, 'Declined', 'Card Error Authentication Required');
        } elseif (strpos(self::$res, 'stolen_card') || strpos(self::$res, 'lost_card') || strpos(self::$str, 'stolen_card') || strpos(self::$str, 'lost_card')) {
            return self::Parser(false, 'Declined', 'Stolen Card');
        } elseif (strpos(self::$res, 'Your card does not support this type of purchase') || strpos(self::$str, 'Your card does not support this type of purchase')) {
            return self::Parser(false, 'Declined', 'Your card does not support this type of purchase');
        } elseif (strpos(self::$res, 'Card payment failed, please try another payment method')) {
            return self::Parser(false, 'Declined', 'Payment failed');
        } elseif (strpos(self::$str, '"cvc_check": "unchecked"') || strpos(self::$str, '"cvc_check": "fail"') || strpos(self::$res, '"cvc_check": "unchecked"') || strpos(self::$res, '"cvc_check": "fail"')) {
            return self::Parser(false, 'Declined', 'Security Code Check: Unchecked');
        } elseif (strpos(self::$res, 'pickup_card') || strpos(self::$str, 'pickup_card')) {
            return self::Parser(false, 'Declined', 'Pickup Card');
        } elseif (strpos(self::$res, 'generic_decline') || strpos(self::$str, 'generic_decline')) {
            return self::Parser(false, 'Declined', 'Generic decline');
        } elseif (strpos(self::$res, 'do_not_honor') || strpos(self::$str, 'do_not_honor')) {
            return self::Parser(false, 'Declined', 'Do not honor');
        } elseif (strpos(self::$res, '"cvc_check":"unavailable"') || strpos(self::$str, '"cvc_check":"unavailable"')) {
            return self::Parser(false, 'Declined', 'CVC check: Unavailable');
        } elseif (strpos(self::$res, "security code is invalid") || strpos(self::$str, "security code is invalid")) {
            return self::Parser(false, 'Declined', 'CVV Invalid');
        } elseif (strpos(self::$res, 'An error occurred while processing your card')) {
            return self::Parser(false, 'Declined', 'Error api provider');
        } elseif (strpos(self::$res, 'Your card number is incorrect') || strpos(self::$res, 'is not a valid credit card number') || strpos(self::$res, 'incorrect_number') || strpos(self::$str, 'incorrect_number')) {
            return self::Parser(false, 'Declined', 'Invalid card number');
        } elseif (strpos(self::$res, 'transaction_not_allowed') || strpos(self::$str, 'transaction_not_allowed')) {
            return self::Parser(false, 'Declined', 'Your card does not support this type of purchase.');
        } elseif (strpos(self::$res, 'HTTP error connecting to Stripe') || strpos(self::$str, 'HTTP error connecting to Stripe')) {
            return self::Parser(false, 'Proxy error', 'Try again', null, 0, true);
        } elseif (strpos(self::$res, "You're not logged in") || strpos(self::$str, "You're not logged in")) {
            return self::Parser(false, 'Cookie error', 'Try again', null, 0, true);
        } elseif (strpos(self::$res, 'Invalid API Key provided') || strpos(self::$str, 'Invalid API Key provided')) {
            return self::Parser(false, 'API key error', 'Try again', null, 0, true);
        } elseif (strpos(self::$res, 'Your card has expired') || strpos(self::$str, 'Your card has expired')) {
            return self::Parser(false, 'Declined', 'Your card has expired');
        } elseif (strpos(self::$res, 'Your card is not supported.') || strpos(self::$str, 'Your card is not supported.')) {
            return self::Parser(false, 'Declined', 'Your card is not supported.');
        } elseif (strpos(self::$res, 'card was declined') || strpos(self::$str, 'card was declined') || strpos(self::$res, 'CardDeclined')) {
            return self::Parser(false, 'Declined', 'Your card was declined');
        }  elseif (strpos(self::$res, 'We are not unable to complete your purchase at this time') || strpos(self::$str, 'We are not unable to complete your purchase at this time')) {
            return self::Parser(false, 'Declined', 'Unable to complete your purchase', null, 0, true);
        } elseif (strpos(self::$res, 'already has the maximum number of payment methods attached') || strpos(self::$str, 'already has the maximum number of payment methods attached')) {
            return self::Parser(false, 'Declined', 'Api dead', null, 0, true);
        } elseif (strpos(self::$res, '"code": "invalid_token"') || strpos(self::$str, '"code": "invalid_token"')) {
            return self::Parser(false, 'Try again', 'Invalid token api', null, 0, true);
        } else {
            return self::Parser(false, 'Declined', self::$res, null, 0, true);
        }
    }

    /**
     * Responses for stripe 3D
     */
    public static function Stripe3D():array
    {
        if (empty(self::$code)) self::$code = null;
        if (empty(self::$res))  self::$res  = null;
        if (empty(self::$str))  self::$str  = null;

        $resp = self::$code ?? self::$res ?? self::$str;
        if (strpos($resp, 'card was declined')) {
            return self::Parser(false, '3D TRUE', 'Lookup error');
        } elseif (strpos($resp, 'Your card has expired')) {
            return self::Parser(false, '3D TRUE', 'Lookup error');
        } elseif (strpos($resp, '"type": "three_d_secure_redirect"')) {
            return self::Parser(false, '3D TRUE', '3D secure redirect');
        } elseif (strpos($resp, '"type": "stripe_3ds2_fingerprint"')) {
            return self::Parser(true, '3D FALSE', 'Lookup Not Enrolled', null, 1);
        } elseif (strpos($resp, '"type": "stripe_3ds2_fingerprint"')) {
            return self::Parser(true, '3D FALSE', 'Lookup Not Enrolled', null, 1);
        } elseif (strpos($resp, 'incorrect_cvc')) {
            return self::Parser(true, '3D FALSE', 'Lookup Not Enrolled', null, 1);
        } elseif (strpos($resp, 'insufficient_funds')) {
            return self::Parser(true, '3D FALSE', 'Lookup Not Enrolled', null, 1);
        } elseif (strpos($resp, '"status": "succeeded"') || strpos($resp, '"status": "complete"')) {
            return self::Parser(true, '3D FALSE', 'Lookup Not Enrolled', null, 1);
        } else {
            return self::Stripe();
        }
    }
}