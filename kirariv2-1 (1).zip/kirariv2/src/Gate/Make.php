<?php

namespace App\Gate;

use App\Models\Bot;
use App\Gate\CurlX;
use App\Config\ErrorLog;
use App\Config\Crypto\Crypto;
use App\Config\Crypto\Key;
use Error;

class Make {
    
    public static int $tries = 0;
    public static int $all_tries = 0;
    public static int $max_tries = 4; // max_tries - 1

    private static $lastHtml;
    private static $lastXml;

    private static array $live = [
        'header' => "-----------[Powered by: @kirarichkbot]-----------\nFormat: ╠CC cc|mm|yy|cvv| bin info | response text | gate name | date\nUser-Data: %s - %s\n\n",
        'body' => "╠CC %s | %s-%s-%s | %s | %s | %s\n"
    ];

    /**
     * Obtener el took total del script
     */
    public static function Took(int $round = 3) {
        $took = round(microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'], $round);
        return $took;
    }

    /**
     * Mensaje mientras el checker esta en proceso
     */
    public static function Wait(int $req, string $cc, string $gate_name, string $lang)
    {
        switch ($req) {
            case 0 : $number = '░░░'; break;
            case 1 : $number = '▓░░'; break;
            case 2 : $number = '▓▓░'; break;
            default : $number = '▓▓▓'; break;
        }
        return sprintf($lang, $gate_name, $number, self::Took(3)."'s", $cc);
    }

    /**
     * Crea una petición cURL para el checker con un max de tries
     * 
     * @param integer $req Request number
     * @param array $site [url, method, post, headers, cookie, proxy]
     * @param array $gate [name, cc, lang]
     * @param array $user [chat_id, msg_id]
     */
    public static function Create(int $req, array $site, array $gate, array $user)
    {
        while (self::$tries < self::$max_tries) {
            // Max number of tries
            if (self::$tries >= self::$max_tries-1) {
                Bot::EditMsgTxt($user['chat_id'], $user['ida'], "<u>λ Gate ".$gate['name']." ☠️</u>\n\n<b><i>Max numbers of tries reached in request $req</i></b>\n<i><b>Took:</b> ".self::Took()."'s | <b>Total tries:</b> ".self::$all_tries."</i>");
                ErrorLog::ReportToChannel('[Req] ['.$res->body.']'.$site['proxy']['AUTH']);
                error_log('Url: ' . $site['url'] . ' | Method: ' . $site['method']);
                error_log('Proxy problem: '.$site['proxy']['AUTH']);
                error_log('Request failed: '.$res->body);
                return false;
            }

            CurlX::Custom($site['url'], $site['method'], $site['post'], $site['headers'], $site['cookie'], $site['proxy']);
            $res = Curlx::Run();

            self::$tries++;
            self::$all_tries++;

            if (!$res->success) {
                Bot::EditMsgTxt($user['chat_id'], $user['ida'], "<u>λ Gate ".$gate['name']." ⚠️</u>\n\n<b><i>Unknown error in request $req</i></b>\n<i><b>Took:</b> ".self::Took()."'s | <b>Tries:</b> ".self::$tries."</i>");
                error_log('Url: ' . $site['url'] . ' | Method: ' . $site['method']);
                error_log('Proxy problem: '.$site['proxy']['AUTH']);
                error_log('Request failed: '.$res->body);
            } else {
                self::$tries = 0;
                return $res;
            }
        }
    }

    /**
     * Analize Xpath HTMLDomDocument
     */
    public static function Analize(?string $htmlString, string $xpathString):array
    {
        libxml_use_internal_errors(true); // Ignore errors
        if ($htmlString != null) {
            //Load new DOMDocument and DOMXPath
            self::$lastHtml = new \DOMDocument();
            self::$lastHtml->loadHTML($htmlString);
            self::$lastXml = new \DOMXPath(self::$lastHtml);
        }

        $res = self::$lastXml->evaluate($xpathString);
        $response = [];
        foreach ($res as $item) {
            $response[] = $item->textContent;
        }
        return $response;
    }

    /**
     * Parse final result
     */
    public static function Parse(string $lang, array $user, string $cc, array $result, array $fim, string $gate_name): string
    {
        $result['card_code'] = (strtoupper($result['card_code']) == 'NULL' || empty($result['card_code'])) ? null : "\n⌧ ".$result['card_code'];
        return sprintf($lang, $gate_name, $result['emoji'], $cc, $result['status'], $result['content'], $result['card_code'], $fim['bin'], $fim['country_name'], $fim['flag'], $fim['brand'], $fim['type'], $fim['level'], $fim['bank_name'].' 💱'.$fim['currency'], \App\Gate\Make::Took(2)."'s", $user['mention'], $user['apodo']);
    }

    /**
     * Ecrypt, decrypt live and save
     * @return string
     */
    public static function SaveLive(bool $save, string $id, string $cc, string $gate_name, array $res, array $bin)
    {
        if (!$save && !$res['live']) return false;

        $path = dirname(dirname(__DIR__)) . '/public/files/lives/' . $id . '.txt';
        $date = date('D, j M Y');
        if (!file_exists($path)) {
            // Create file | Save data manual and return encryted data
            $key = Key::generate($path.'.enc');
            $content = sprintf(self::$live['body'], $cc, $bin['flag'], $bin['type'], $bin['level'], $res['content'], $gate_name, $res['status'], $date);

            $handler = fopen($path, 'wb');
            fwrite($handler, Crypto::EncryptText($content, $key));
            fclose($handler);
            return $content;
        } else {
            // Decrypt file | Save data manual and return encryted data
            $key = Key::read($path.'.enc');
            $data = Crypto::DecryptText(Key::read($path), $key);
            $data .= sprintf(self::$live['body'], $cc, $bin['flag'], $bin['type'], $bin['level'], $res['content'], $gate_name, $res['status'], $date);
            $handler = fopen($path, 'wb');
            fwrite($handler, Crypto::EncryptText($data, $key));
            fclose($handler);

            return $data;
        }

    }
}
