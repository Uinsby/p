<?php

namespace App\Gate;

use App\Gate\Validate;

/**
 * Gen and validate credit cards
 */
class Gen
{

    public static $luhn = 0;

    /**
     * Generar un mes aleatorio
     */
    private static function GenMonth(?string $mes = null, $year = null)
    {
        $mes = self::QuitString($mes);

        if (empty($mes) && date('Y') != $year) {
            // Generar un mes aleatorio
            $mes = rand(01, 12);
            return str_pad($mes, 2, '0', STR_PAD_LEFT);
        } elseif (empty($mes)) {
            // Generar un mes aleatorio a partir del año
            $mes = rand(date('m'), 12);
            return str_pad($mes, 2, '0', STR_PAD_LEFT);
        } else {
            // Mes especificado
            return str_pad($mes, 2, '0', STR_PAD_LEFT);
        }
    }

    /**
     * Generar un año aleatorio
     */
    private static function GenYear(?string $year = null)
    {
        $year = self::QuitString($year);

        if (empty($year)) {
            $year_ac = date('Y'); // Año Actual
            return mt_rand($year_ac, $year_ac + 10);
        }
        return (strlen($year) == 2) ? '20' . $year : $year;
    }

    /**
     * Generar un cvv aleatorio a partir de un prefix
     */
    private static function GenCvv(?string $prefix, $length = 3)
    {
        $cvv = self::QuitString(self::QuitX($prefix));

        while (strlen($cvv) < $length) {
            $cvv .= mt_rand(0, 9);
        }

        return $cvv;
    }

    /**
     * Eliminar las "x" de un string y reemplazarlas por un numero pseudo-aleatorio
     */
    public static function QuitX(string $str = null): string
    {
        $str = preg_replace('/[^0-9]/', 'x', $str);
        $length = strlen($str);

        for ($i = 0; $i < $length; $i++) {
            if ($str[$i] == 'x') {
                $str[$i] = self::GenRandNumber();
            }

        }
        return $str;
    }

    /**
     * Obtener un numero pseudo-aleatorio
     */
    private static function GenRandNumber($length = 1): string
    {
        $int = '1234567890';
        $random = null;
        for ($i = 0; $i < $length; $i++) {
            $random .= $int[mt_rand(0, 9)];
        }
        return $random;
    }

    /**
     * Eliminar todas las letras de un string con regex
     */
    private static function QuitString(?string $str)
    {
        return preg_replace('/[^0-9]/', '', $str);
    }

    /**
     * Completar una CC
     */
    public static function CompletNumber($prefix, $length)
    {
        $prefix = self::QuitString(self::QuitX($prefix));

        while (strlen($prefix) < $length) {
            $prefix .= self::GenRandNumber();
        }
        $length_sub = (strlen($prefix) == $length) ? $length : $length - 1;
        $ccnumber = substr(self::QuitString($prefix), 0, $length_sub);

        # Calculate sum
        $sum = 0;
        $pos = 0;
        $reversedCCnumber = strrev($ccnumber);

        while ($pos < $length - 1) {
            $odd = $reversedCCnumber[$pos] * 2;
            if ($odd > 9) {
                $odd -= 9;
            }
            $sum += $odd;
            if ($pos != ($length - 2)) {
                $sum += $reversedCCnumber[$pos + 1];
            }
            $pos += 2;
        }
        # Calculate check digit
        $checkdigit = ((floor($sum / 10) + 1) * 10 - $sum) % 10;
        $ccnumber .= (strlen($ccnumber) == $length) ? null : $checkdigit;
        return $ccnumber;
    }

    /**
     * Generar 100 CCS y obtener el % de validas
     */
    private static function Val($prefix, $mes = null, $year = null, $cvv = null, $cant = 10) : array
    {
        // Generar un array de CCs
        $length = ($prefix[0] == '3') ? [4, 15] : [3, 16];
        $ccs = [];
        for ($i = 0; $i < $cant; $i++) {
            $cc = self::CompletNumber($prefix, $length[1]);
            $sum = (Validate::luhn($cc)) ? 1 : 0;
            self::$luhn += $sum;
            if ($sum == 1) {
                $ccs['cc'][] = $cc . '|' . self::GenMonth($mes, $year) . '|' . self::GenYear($year) . '|' . self::GenCvv($cvv, $length[0]);
            }
        }
        $ccs['data']['total'] = count(@$ccs['cc']);
        $ccs['data']['luhn'] = (self::$luhn * 100) / $cant;
        return $ccs;
    }

    /**
     * Generar las CCS
     */
    public static function Complet($prefix, $mes = null, $year = null, $cvv = null, $cant = 10) : array
    {
        // Generar un array de CCs
        $ccs = self::Val($prefix, $mes, $year, $cvv, 100);

        if ($ccs['data']['luhn'] < 10) {
            return ['ok' => false, 'luhn' => $ccs['data']['luhn'], 'error' => "Try again, " . (100 - $ccs['data']['luhn']) . "% of the CC's do not pass luhn"];
        }

        return ['ok' => true, 'luhn' => $ccs['data']['luhn'], 'ccs' => array_slice($ccs['cc'], 0, $cant)];
    }

    public static function Validate(array $input) {
        // Validar que los campos esten completos
        Validate::SetGen(true);
        $exp = Validate::ValidateExpired(@$input[1], @$input[2]);
        if (!$exp['ok']) return $exp;

        $cvv = Validate::Cvv(@$input[3], @$input[0]);
        if (!$cvv['ok']) return $cvv;

        $cc = Validate::CardLenght(@$input[0]);
        if (!$cc['ok']) return $cc;

        if (!Validate::CardType($input[0])) return ['ok' => false, 'msg' => 'Only Amex, Visa, Mastercard or discover is accepted'];
        return ['ok' => true, 'msg' => ''];
    }
}
