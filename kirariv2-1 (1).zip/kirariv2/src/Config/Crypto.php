<?php

namespace App\Config;

class Crypto {

}