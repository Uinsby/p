// TODO: Falta el mass (callback and initializer)
// TODO: comando /me en callback and message
