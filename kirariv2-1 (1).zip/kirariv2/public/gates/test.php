<?php
ob_start();
passthru("python3 rev3.py -anchor 'https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LeINU0bAAAAAFIQNz4Bc_d7mbDzeBMENU3LBZN_&co=aHR0cHM6Ly9hbWVyaWNhbmNvdW5jaWxvbmVkLmZvcm1zdGFjay5jb206NDQz&hl=es&v=0aeEuuJmrVqDrEL39Fsg5-UJ&size=invisible&cb=epo81w8oek1e'");
$output = ob_get_clean(); 
echo $output;
