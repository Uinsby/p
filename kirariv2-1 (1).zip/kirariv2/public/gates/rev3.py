#!/usr/bin/env python3
from pypasser import reCaptchaV3
import argparse
import json
                                                                                                                                      
parser = argparse.ArgumentParser()                                                                                                    
parser.add_argument("-anchor",help="please put the recaptchav3 anchor")
args = parser.parse_args()                                                                                                            
anchor = args.anchor                                                                                                                  
reCaptcha_response = reCaptchaV3(anchor)                                                                                              
result = {
	"Anchor": anchor,
	"Type": "ReCaptcha V3",
	"Recaptcha_Response": reCaptcha_response
}

res = json.dumps(result)
f = open("test.txt", "a+")
f.write(res)
f.close()
print("xd")
