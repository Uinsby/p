<?php

use App\Config\ErrorLog;
use App\Config\MailTm;

use App\Models\Bot;
use App\Models\Mail;

$acc = MailTm::CreateAccount();

if (!$acc['ok']) {
    Bot::SendMsg($chat_id, "☠️ <i>Network error</i>", $message_id);
    exit;
}

$accid = Mail::Save($acc['mail'], $acc['pass'], $acc['accid']);

$keyboard = ['inline_keyboard' => [
    [['text' => '📥 Imbox', 'callback_data' => 'mail ' . $id . '|' . $accid . '|dm|1'], ['text' => '🗑 Delete', 'callback_data' => 'mail ' . $id . '|' . $accid . '|del']],
    [['text' => '🌐 Login', 'url' => 'https://mail.tm/']],
]];

$ida = Bot::SendMsg($chat_id, "<b><i>Account was created successfully!</i>\nMail: <code>" . $acc['mail'] . "</code>\nPass: <code>" . $acc['pass'] . "</code>\nAccount id:</b> <code>" . $acc['accid'] . "</code>", $message_id, $keyboard)['result']['message_id'];

$token = MailTm::GetToken();

if (!$token['ok']) {
    ErrorLog::ReportToChannel('[mail] [token] Fail to create token to account ' . $acc['mail']);
    Bot::EditMsgTxt($chat_id, $ida, '<b>❌ <u>Network error</u> No se pudo crear el jwt token para esta cuenta, intente nuevamente en unos minutos</b>');
    exit;
}
Mail::UpdateToken($accid, $token['token']);
Mail::DeleteOld(10);