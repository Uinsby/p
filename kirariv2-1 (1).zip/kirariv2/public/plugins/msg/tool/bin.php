<?php

use App\Gate\Bin;
use App\Models\Bot;

$bin = Bot::GetContent($message, 5, ['send' => false, 'chat_id' => $chat_id, 'msg' => "<b>λ <i>Bin lookup</i> ♻️\nFormat:</b> <code>".$t."bin ".rand(300000, 699999)."</code>", 'msg_id' => $message_id]);

if (strlen($bin) < 6) {
    Bot::SendMsg($chat_id, "<b>λ <i>Bin lookup</i> ♻️\nFormat:</b> <code>".$t."bin ".rand(300000, 699999)."</code>", $message_id);
    exit;
}

$fim = Bin::Get($bin);

if (!$fim['ok']) {
    // Invalid bin
    $txt = sprintf($lang['bin']['invalid'], $fim['bin']);
    Bot::SendMsg($chat_id, $txt, $message_id);
} else {
    $txt = sprintf($lang['bin']['valid'], $fim['bin'], $fim['brand'], $fim['type'], $fim['level'], $fim['bank_name'], $fim['bank_phone'], $fim['country_name'], $fim['ISO3'], $fim['flag'], $fim['currency'], $f['mention'], $f['apodo']);
    Bot::SendMsg($chat_id, $txt, $message_id);
}
