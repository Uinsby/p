<?php

use App\Models\Bot;

$query = Bot::GetContent($message, 8, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg' => "<b><i>ExpressVpn key</i> checker\nFormat:</b> <code>" . $t . "expkey " . $cmd['form'] . "</code>",
    'msg_id' => $message_id,
]);

$url = "https://www.ftrftcx.net/vpn_servers?activation_code=".urlencode($query)."&ca_version=2&client_version=6.7.1&conn_requests=1&device_id=%3CPokiSimp2%3E&device_name=Windows&dpi=hdpi&include_country_and_region=1&include_pptp_l2tp_ipsec_servers=1&include_recommended_clusters=1&include_sstp_servers=1&os_version=win6.2.0&show_messages=1&smart_location=1";

$xml = simplexml_load_file($url);

if (isset($xml->error_message)) {
    $txt = "🚫 <i><u>".$xml->error."</u> ".$xml->error_code."</i>\n<b>Reason:</b> <i>".$xml->error_message."</i>";
    Bot::SendMsg($chat_id, $txt, $message_id);
    exit; // Dd key
}

if (isset($xml->subscription)) {

    $sub = $xml->subscription;
    $status = $sub->status;

    switch ($status) {
        case 'ACTIVE': case 'FREE_TRIAL_ACTIVE': $emoji = '✅'; break;
        case 'EXPIRED': case 'FREE_TRIAL_EXPIRED': $emoji = '❌'; break;
        case 'PENDING': $emoji = '⏳'; break;
        case 'SUSPENDED': case 'CANCELLED': $emoji = '⛔'; break;
        default: $emoji = '⚠️'; break;
    }

    $txt = "<b>Valid key ".$emoji."\nStatus:</b> ".$status."\n<b>Trial Type:</b> ".@$sub->free_trial_type."\n<b>Plan Type:</b> ".@$sub->plan_type."\n<b>Expiration:</b> ".@$sub->expiration_date;
    Bot::SendMsg($chat_id, $txt, $message_id);
    exit;
}

Bot::SendMsg($chat_id, 'Unknown status key', $message_id);