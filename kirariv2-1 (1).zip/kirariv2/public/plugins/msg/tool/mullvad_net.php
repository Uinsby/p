<?php

use App\Config\ErrorLog;
use App\Config\StringUtils;
use App\Gate\CurlX;
use App\Models\Bot;

$query = Bot::GetContent($message, 7, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b><i>λ MullvadVpn keychecker ♻️</i>\nFormat:</b> <code>".$t."mullk ".$cmd['form']."</code>"
]);

$ida = Bot::SendMsg($chat_id, "<i>Checking your key, please wait...</i>", $message_id)['result']['message_id'];

const API_URL = 'https://api.mullvad.net/www/accounts/';

$key = StringUtils::RemoveSpaces($query);

$res = CurlX::Get(API_URL.$key)->body;
$response = json_decode($res, true);

if (isset($response['code'])) {
    Bot::EditMsgTxt($chat_id, $ida, "<b>Invalid key ❌\nKey: <code>".$query."</code>\nReason:</b> <i>".$response['code']."</i>");
    exit;
}
if (isset($response['account'])) {

    $account = $response['account'];
    $token = $account['pretty_token'];
    $expired = date('M d, Y', $account->expiry_unix);
    $active = match($account['active']) {true => 'Active ✅', default => 'Inactive ❌'};
    $max_ports = @$account['max_wg_peers'];
    $max_peers = @$account['max_wg_peers'];
    $ipv4 = @$account['wg_peers']['0']['ipv4_address'];
    $ipv6 = @$account['wg_peers']['0']['ipv6_address'];

    $text = "<b>Valid key\nKey: <code>".$token."</code>\nStatus: <i>".$active."</i>\nExpired:</b> ".$expired."\n<b>Max ports:</b> <code>".$max_ports."</code>\n<b>Max peers:</b> <code>".$max_peers."</code>\n<b>IPv4:</b> <code>".$ipv4."</code>\n<b>IPv6:</b> <code>".$ipv6."</code>";

    Bot::EditMsgTxt($chat_id, $ida, $text);
    exit;
}

Bot::SendMsg($chat_id, '<b><i>Unknown Status</i></b>', $message_id);
ErrorLog::ReportToChannel('[mullvad_net] Unknown Status '.StringUtils::QuitHtml($res));