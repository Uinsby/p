<?php

use App\Models\Bot;

Bot::SendMsg($chat_id, '<b>Select a proxy type</b>', $message_id, [
  'inline_keyboard' => [
    [
      ['text' => 'HTTPS', 'callback_data' => 'proxy '.$id.'|https'],
      ['text' => 'SOCKS 4', 'callback_data' => 'proxy '.$id.'|socks4'],
      ['text' => 'SOCKS 5', 'callback_data' => 'proxy '.$id.'|socks5']
    ], [
      ['text' => 'Delete 🗑', 'callback_data' => 'finalize|'.$id]
    ]
  ]
]);
