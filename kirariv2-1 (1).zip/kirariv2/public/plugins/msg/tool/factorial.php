<?php

use App\Models\Bot;
use App\Config\StringUtils;

$query = Bot::GetContent($message, 11, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg' => "<b><i>Get Factorial Of Number</i>\nFormat:</b> <code>" . $t . "factorial " . $cmd['form'] . "</code>",
    'msg_id' => $message_id
]);

$query = (int) StringUtils::CleanString($query, 'bin');
Bot::SendMsg($chat_id, '<i>Factorial de '.$query.':</i> <code>'.obtieneFactorial($query).'</code>', $message_id);

function obtieneFactorial(int $numero){
  $factorial = 1;
  for ($i = 1; $i <= $numero; $i++){
    $factorial *= $i;
  }
  return $factorial;
}