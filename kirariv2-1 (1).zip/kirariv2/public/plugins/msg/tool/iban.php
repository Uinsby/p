<?php

use App\Gate\CurlX;
use App\Models\Bot;

$query = Bot::GetContent($message, 6, [
    'send' => true,
    'chat_id'  => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b><i>λ Iban Checker</i>\nFormat:</b> <code>".$t."iban ".$cmd['form']."</code>"
]);

const API_URL = 'https://api.ibanapi.com/v1/validate/';
const API_TOKEN = '87dc7a88fc70b4d46bb9c8b8d76d1dc033a88afc';

$datas = json_decode(CurlX::Get(API_URL.$query.'?api_key='.API_TOKEN)->body, true);

if ($datas['result'] != 200) {
    // Invalid iban
    $errors = $datas['validations'];
    $txt = "<b><i>❌ ".$datas['message']."</i>\n\nValidations:</b>\n";

    foreach ($errors as $key => $value) {
        $txt .= " ".($key+1).". <i>".$value['message']."</i>\n";
    }
    Bot::SendMsg($chat_id, $txt, $message_id);
    exit;
}

$data = $datas['data'];
$sepa = $data['sepa'];
$bank = $data['bank'];

$txt = "<i><b>✅ ".$datas['message']."\n\nCountry:</b> ".$data['country_name']." / ".$data['country_code']."\n<b>Bbank</b> ".$data['bban']."\n<b>Bank account:</b> ".$data['bank_account']."\n<u>Bank:</u>\n  <b>- Address:</b> ".$bank['address']."\n  <b>- Phone:</b> ".$bank['phone']."\n  <b>- Name:</b> ".$bank['bank_name']."\n  <b>- State:</b> ".$bank['state']."\n  <b>- City:</b> ".$bank['city']."\n  <b>- Bic:</b> ".$bank['bic']."\n  <b>- Zip:</b> ".$bank['zip']."\n<u>Sepa:</u>\n  <b>- Credit transfer:</b> ".$sepa['sepa_credit_transfer']."\n  <b>- Card Clearing:</b> ".$sepa['sepa_card_clearing']."\n  <b>- Direct debit:</b> ".$sepa['sepa_direct_debit']."\n  <b>- Sdd core:</b> ".$sepa['sepa_sdd_core']."\n  <b>- Member:</b> ".$data['sepa_member']."\n  <b>- B2b:</b> ".$sepa['sepa_b2b']."</i>";

Bot::SendMsg($chat_id, $txt, $message_id);