<?php

use App\Models\Bot;
use App\Gate\Bin;
use App\Models\User;

$bin = Bot::GetContent($message, 7, ['send' => true, 'chat_id' => $chat_id, 'msg_id' => $message_id, 'msg' => "<b>λ <i>Extras lookup</i>\nFormat:</b> <code>".$t."extra ".$cmd['form']."</code>\n\n<i><u>Note:</u> 1 credit = 10 extras</i>"]);

if (empty($bin)) {
    Bot::SendMsg($chat_id, "<b>λ <i>Extras lookup</i>\nFormat:</b> <code>".$t."extra ".$cmd['form']."</code>", $message_id); exit;
}
if ($f['creditos'] < 5) {
    Bot::SendMsg($chat_id, "<b>⚠️ You don't have enough credits to use this command</b>", $message_id); exit;
}

$fim = Bin::Get($bin);

if (!$fim['ok']) {
    Bot::SendMsg($chat_id, "⚠️ <b><i>".$fim['error']."</i></b>", $message_id); exit;
}

$extra = Bin::Extras($fim['bin'], '0', '10');

if (!$extra['ok']) {
    Bot::SendMsg($chat_id, "⚠️ <b><i>".$extra['error']."</i></b>", $message_id); exit;
}

$total_extras = count($extra['extras']);
$keyboard = ['inline_keyboard' => [
    [['text' => 'Next page ➡️', 'callback_data' => 'extra '.$id.'|'.$bin.'|0|0']]
]];
if ($total_extras < 10) $keyboard = null;

Bot::SendMsg(
    $chat_id,
    "<i><b>".$fim['flag']." - ".$fim['brand']." - ".$fim['type']." - ".$fim['level']."</b>\n<u>Page:</u> 1 | <u>Took:</u> ".User::GetTook(true, 3)."'s| <u>Results:</u> ".count($extra['extras'])."</i>\n\n".implode("\n",$extra['extras']),
    $message_id,
    $keyboard
);
Bot::SendMsg($chat_id, '<i>-1 credit</i>');

User::Update($id, $f['status'], $f['staff'], $f['creditos'] - 1, $f['save_live'], $f['member_expired'], $f['credit_expired'], $f['apodo'], $f['antispam']);
