<?php

use App\Models\Bot;
use App\Gate\Bin;

$query = Bot::GetContent($message, 6, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg' => "<b>λ <i>Bin gen</i></b>\n".sprintf($cmd['form'], $t,$t,$t,$t),
    'msg_id' => $message_id
]);

switch (strtolower($query)) {
    case 'a': case 'amex': $first = 3; break;
    case 'v': case 'visa': $first = 4; break;
    case 'm': case 'mastercard': $first = 5; break;
    case 'd': case 'discover': $first = 6; break;
    default: $first = false; break;
}

if ($first == false) {
    Bot::SendMsg($chat_id, "<b>❌ Invalid format\nUnknow type <u>".$query."</u></b>", $message_id);
    exit;
}

$fim = Bin::Get($first.rand(10000, 99999));

if (!$fim['ok']) {
    $txt = sprintf($lang['bin']['invalid'], $fim['bin']);
    Bot::SendMsg($chat_id, $txt, $message_id, [
        'inline_keyboard' => [
            [
                ['text' => 'Try again 🔁', 'callback_data' => 'gbin '.$id.'|'.$first]
            ]
        ]
    ]);
} else {
    $txt = sprintf($lang['bin']['valid'], $fim['bin'], $fim['brand'], $fim['type'], $fim['level'], $fim['bank_name'], $fim['bank_phone'], $fim['country_name'], $fim['ISO3'], $fim['flag'], $fim['currency'], $f['mention'], $f['apodo']);
    Bot::SendMsg($chat_id, $txt, $message_id, [
        'inline_keyboard' => [
            [
                ['text' => 'Gen again ♻️', 'callback_data' => 'gbin '.$id.'|'.$first]
            ]
        ]
    ]);
}