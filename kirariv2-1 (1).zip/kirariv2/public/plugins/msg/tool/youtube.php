<?php

use App\Gate\CurlX;
use App\Models\Bot;

$query = Bot::GetContent($message, 9, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b><i>♻️ YouTube search</i>\nFormat:</b> <code>".$t."youtube ".$cmd['form']."</code>",
]);

const API_URL = 'https://api.abirhasan.wtf/youtube?query=%s&limit=15';
$url = sprintf(API_URL, urlencode($query));

$ida = Bot::SendMsg($chat_id, '<b>♻️ <i>Searching, please wait...</i></b>', $message_id)['result']['message_id'];

$result = json_decode(CurlX::Get($url)->body, true);

if (isset($result['error'])) {
    // Error in search
    Bot::EditMsgTxt($chat_id, $ida, '<i>'.$result['error'].'</i>');
    exit;
}

$data = $result['results'];
$text = "<b>Query: <i>".urldecode($result['query'])."</i>\nLimit: <code>".$result['limit']."</code> | Results: <code>".count($data)."</code>\n\nResquest by:</b> ".$f['mention']." [".$f['apodo']."]";

// Create the button
$button = array();
for ($i=0; $i < count($data); $i++) { 
    $button['inline_keyboard'][$i][0]['text'] = $data[$i]['title'];
    $button['inline_keyboard'][$i][0]['url']  = urldecode($data[$i]['link']);
}

Bot::EditMsgTxt($chat_id, $ida, $text, $button);