<?php

use App\Models\Bot;

$query = Bot::GetContent($message, 9, [
    'send' => true,
    'msg' => "<b><i>λ Webshot from websites</i> 📸\nFormat:</b> <code>".$t."webshot ".$cmd['form']."</code>",
    'msg_id' => $message_id,
    'chat_id' => $chat_id
]);

if (!filter_var($query, FILTER_VALIDATE_URL)) {
    Bot::SendMsg($chat_id, "<b>Please provide a valid url, e.g:</b> <code>https://google.com</code>", $message_id);
    exit;
}

$ida = Bot::SendMsg($chat_id, "♻️ <b>Generating webshot, please wait</b>", $message_id)['result']['message_id'];

$header_webshot = ['Host: urlbox.io', 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101 Firefox/91.0', 'Accept: */*', 'Accept-Language: es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3', 'Accept-Encoding: gzip, deflate, br', 'Referer: https://urlbox.io/', 'Content-Type: application/json', 'Origin: https://urlbox.io'];
$data = basicCurl('https://urlbox.io/api/render', [
    CURLOPT_SSL_VERIFYPEER    => false,
    CURLOPT_RETURNTRANSFER    => true,
    CURLOPT_MAXCONNECTS       => 1000,
    CURLOPT_POST              => true,
    CURLOPT_HTTPHEADER        => $header_webshot,
    CURLOPT_POSTFIELDS        => json_encode(['url' => $query])
]);

$datas = json_decode($data, true);
$screenshotUrl = $datas['screenshotUrl'];

$rp = Bot::sendDocument([
    'chat_id'             => $chat_id,
    'document'            => $screenshotUrl,
    'caption'             => '<b>Input:</b> <code>'.$query.'</code>',
    'parse_mode'          => 'HTML',
    'reply_to_message_id' => $message_id
]);

if (!$rp['ok']) {
    Bot::EditMsgTxt($chat_id, $ida, $rp['description']); exit;
}

Bot::DelMsg($chat_id, $ida);




function basicCurl($url, $options=[]) {
    $ch = curl_init($url);
    curl_setopt_array($ch, $options);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
};