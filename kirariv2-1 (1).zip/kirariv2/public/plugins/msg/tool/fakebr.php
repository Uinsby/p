<?php

use App\Gate\CurlX;
use App\Models\Bot;

const BASE_URL = 'https://geradornv.com.br/wp-json/api/';

$query = Bot::GetContent($message, 8, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg' => "<b><i>Random brasilian data</i> 🇧🇷\nFormat:</b> <code>".$t."fakebr option</code>",
    'msg_id' => $message_id
]);

$options = [
    'cep' => ['desc' => 'Números de CEP do Brasil inteiro', 'url' => 'cep/random-by-states?state='],
    'name' => ['desc' => 'Crie quantos nomes quiser ', 'url' => 'generator-name'],
    'person' => ['desc' => 'Gerar dados completos de uma pessoa.', 'url' => 'generator-people?sex=x&state=']
];

$states = ["AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "RS", "SC", "SE", "SP", "TO"];
$state = $states[array_rand($states)];

if ($query == 'cep') {
    $url = BASE_URL . $options[$query]['url'] . $state;
    $data = json_decode(CurlX::Get($url)->body, true);
    $txt = "<b>Cep: <code>".$data['cep']."</code>\nRua:</b> <i>".$data['street']."</i>\n<b>Vizinhança</b> <i>".$data['neighborhood']."</i>\n<b>Cidade</b> <i>".$data['city']."</i>\n<b>Estado</b> <i>".$data['state']."</i>\n<b>Tipo</b> <i>".$data['type']."</i>";
    Bot::SendMsg($chat_id, $txt, $message_id);
    exit;
}

if ($query == 'name') {
    $url = BASE_URL . $options[$query]['url'];
    $data = json_decode(CurlX::Get($url)->body, true);
    $txt = "<b>Nome completo:</b> <i>".$data['fullname']."</i>";
    Bot::SendMsg($chat_id, $txt, $message_id);
    exit;
}

if ($query == 'person') {
    $url = BASE_URL . $options[$query]['url'] . $state;
    $data = json_decode(CurlX::Get($url)->body, true);
    $txt = "<b>Name completo:</b> <i>".$data['people']."</i>\n<b>Mãe:</b> <i>".$data['mom']."</i>\n<b>Pai:</b> <i>".$data['dad']."</i>\n\n<b><u>CEP:</u></b>\n";
    $data = $data['cep'];
    $txt .= "<b>  - Cep: <code>".$data['cep']."</code>\n  - Rua:</b> <i>".$data['street']."</i>\n<b>  - Vizinhança</b> <i>".$data['neighborhood']."</i>\n<b>  - Cidade</b> <i>".$data['city']."</i>\n<b>  - Estado</b> <i>".$data['state']."</i>\n<b>  - Tipo</b> <i>".$data['type']."</i>";
    Bot::SendMsg($chat_id, $txt, $message_id);
    exit;
}


$txt = '';

foreach ($options as $key => $item) {
    $txt .= "<code>{$t}fakebr $key</code> - <i>$item[desc]</i>\n";
}
Bot::SendMsg($chat_id, $txt, $message_id);