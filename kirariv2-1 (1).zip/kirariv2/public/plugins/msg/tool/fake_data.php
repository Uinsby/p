<?php

use App\Gate\CurlX;
use App\Models\Bot;

$query = Bot::GetContent($message, 6, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg' => "<b>λ <i>Fake data generator</i>\nFormat:</b> <code>".$t."fake country_code</code>\n<i>For see the country codes, type:</i> <code>".$t."fake codes</code>",
    'msg_id' => $message_id
]);

$countries = ['au', 'br', 'ca', 'ch', 'de', 'dk', 'es', 'fi', 'fr', 'gb', 'ie', 'ir', 'no', 'nl', 'nz', 'tr', 'us'];

if ($query == 'code' || $query == 'codes') {
    Bot::SendMsg($chat_id, "<b><i>λ Country codes available:</i>\n☉</b> <code>".implode(', ', $countries)."</code>", $message_id);
    exit;
}

if (!in_array(strtolower($query), $countries)) {
    Bot::SendMsg($chat_id, "<b><i>❌ Country codes available:</i>\n☉</b> <code>".implode(', ', $countries)."</code>", $message_id);
    exit;
}

$data = json_decode(CurlX::Get('https://randomuser.me/api/?nat='.strtolower($query))->body, true);

if (!$data || isset($data['error'])) {
    Bot::SendMsg($chat_id, "<i>Uh oh, something has gone wrong</i>", $message_id);
    exit;
}

$mails = ['gmail.com', 'hotmail.com', 'outlook.com', 'outlook.br', 'outlook.jp', 'gmx.es', 'protonmail.com'];
$mails = $mails[array_rand($mails)];
$results = $data['results']['0'];
$urla = $results['picture']['large'];
$location = $results['location'];
$street = $location['street'];
$names = $results['name'];

Bot::SendAction($chat_id, 'upload_photo');

Bot::sendphoto([
    'chat_id' => $chat_id,
    'reply_to_message_id' => $message_id,
    'caption' => "<b>Gender: <code>".ucfirst($results['gender'])."</code>\nName: <code>".$names['title']." ".$names['first']." ".$names['last']."</code>\nMail: <code>".str_replace('example.com', $mails, $results['email'])."</code>\nPhone: <code>".$results['phone']."</code>\nCell: <code>".$results['cell']."</code>\nStreet: <code>".$street['name']." ".$street['number']."</code>\nLocation: <code>".$location['city']." - ".$location['state']."</code>\nPostcode: <code>".$location['postcode']."</code>\nCountry:</b> <code>".$location['country']."</code>",
    'parse_mode' => 'html',
    'photo' => $urla,
    'reply_markup' => json_encode([
        'inline_keyboard' => [
          [['text' => 'Gen again ('.$location['country'].') ⚙', 'callback_data' => 'fake '.$id.'|'.strtolower($query)]]
        ]
      ])
]);