<?php

use App\Gate\CurlX;
use App\Models\Bot;

$query = Bot::GetContent($message, 5, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b><i>λ Github user search ♻️</i>\nFormat:</b> <code>".$t."git ".$cmd['form']."</code>"
]);

const GITHUB_URL = 'https://api.github.com/users/';

$git = json_decode(CurlX::Get(GITHUB_URL . urlencode($query), ['User-Agent' => 'Mozilla/5.0 (X11; U; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4647.129 Safari/537.36'])->body, true);

if (isset($git['message'])) {
    Bot::SendMsg($chat_id, sprintf($lang['github']['invalid'], $git['message']), $message_id);
    exit;
}

$repos_url = $git['repos_url'];
$repositorys = json_decode(CurlX::Get($repos_url, ['User-Agent' => 'Mozilla/5.0 (X11; U; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4647.129 Safari/537.36'])->body, true);
$total_repos = count($repositorys);
$repos = array();

if ($total_repos < 1) {
    $repos['inline_keyboard'][1][0] = ['text' => 'Github Profile', 'url' => $git['html_url']];
} else {
    for ($i=0; $i < $total_repos && $i < 11; $i++) { 
        $repos['inline_keyboard'][$i][0] = ['text' => $repositorys[$i]['name'], 'url' => $repositorys[$i]['html_url']];
    }
}

foreach ($git as $key => $value) {
    $git[$key] = $value ?? 'Null';
}
$caption = sprintf($lang['github']['valid'], '<a href="'.$git['html_url'].'">'.$git['login'].'</a>', $git['id'], $git['bio'], $git['blog'], $git['company'], $git['twitter_username'], $git['public_repos'], $git['public_gists'], $git['followers'], $git['following'], $f['mention'], $f['apodo']);

if ($git['avatar_url'] != 'Null') {
    // Send profile picture
    Bot::sendDocument([
        'chat_id'             => $chat_id, 
        'reply_to_message_id' => $message_id,
        'parse_mode'          => 'HTML',
        'document'            => $git['avatar_url'],
        'caption'             => $caption,
        'reply_markup'        => json_encode($repos)
    ]);
} else {
    Bot::SendMsg($chat_id, $caption, $message_id, $repos, 'html', true);
}