<?php

use App\Models\Bot;
use App\Config\StringUtils;
use App\Gate\Bin;
use App\Gate\Gen;

// CC-gen and validate

$input = Bot::GetContent($message, 4, ['send' => true, 'chat_id' => $chat_id, 'msg' => "<b>λ <i>CC-gen tool</i>\nFormat:</b> <code>".$t."gen ".$cmd['form']."</code>", 'msg_id' => $message_id]);
$input = str_replace(['rand', 'rnd', 'random'], 'x', $input);
$bim = substr($input, 0, 6);

$fim = Bin::Get($bim);

if (!$fim['ok']) {
    Bot::SendMsg($chat_id, '⚠️ <b><i>'.$fim['error'].'</i></b>', $message_id); exit;
}

$cgen = explode('|', StringUtils::CleanString($input));
$val = Gen::Validate($cgen);

if (!$val['ok']) {
    Bot::SendMsg($chat_id, '⚠️ <b><i>'.$val['msg'].'</i></b>', $message_id); exit;
}

for ($i=0; $i < 4; $i++) { 
    $cgen[$i] = $cgen[$i] ?? 'rnd';
    $cgen[$i] = $cgen[$i] == 'x' ? 'rnd' : $cgen[$i];
}

$gen = Gen::Complet($cgen[0], $cgen[1], $cgen[2], $cgen[3]);

$Strl = ($cgen[0] == 3) ? 15 : 16;
$card = $cgen[0].str_repeat('x', $Strl - strlen($cgen[0]));
$ccgen = implode('|', [$card, $cgen[1], $cgen[2], $cgen[3]]);

if ($gen['ok']) {
    Bot::SendMsg($chat_id, "<b>Input:</b> <code>".$ccgen."</code>\n\n<code>".implode("\n", $gen['ccs']).'</code>', $message_id, ['inline_keyboard' => [
        [
            ['text' => 'Gen Again ⚙', 'callback_data' => 'gen '.$id.'|'.implode('|', $cgen) ],
            ['text' => 'Bin Info ♻️', 'callback_data' => 'bin '.$fim['bin'] ],
        ], [
            ['text' => 'Delete 🗑', 'callback_data' => 'finalize|'.$id ]
        ]
    ]]);
} else {
    Bot::SendMsg($chat_id, '⚠️ <b><i>'.$gen['error'].'</i></b>', $message_id, ['inline_keyboard' => [
        [
            ['text' => 'Try again ⚙', 'callback_data' => 'gen '.$id.'|'.implode('|', $cgen) ]
        ]
    ]]); exit;
}