<?php

use App\Config\StringUtils;
use App\Gate\CurlX;
use App\Models\Bot;

$_lang = ($f['lang'] == 'en') ? 'en' : 'es';

const WIKIPEDIA_API = 'https://%s.wikipedia.org/w/api.php?action=query&list=search&srprop=snippet&format=json&origin=*&utf8=&srsearch=%s';

$query = Bot::GetContent($message, 6, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b><i>λ Wikipedia search</i>\nFormat:</b> <code>".$t."wiki ".$cmd['form']."</code>"
]);

$res = CurlX::Get(sprintf(WIKIPEDIA_API, $_lang, urlencode($query)));

if (!$res->success) {
    Bot::SendMsg($chat_id, '<b>cURL Error</b>: '.$res->error, $message_id);
    exit;
}

$wiki = json_decode($res->body, true);
$result = $wiki['query']['search'];
$count = count($result);
if ($count == 0) {
    Bot::SendMsg($chat_id, "<b>⚠ No results found ➜ <code>".$query."</code>\nSuggestion:</b> <code>".$wiki['query']['searchinfo']['suggestion']."</code>", $message_id);
    exit;
}

$title = $result['0']['title'];
$pageId = $result['0']['pageid'];
$snippet = strip_tags($result['0']['snippet']);
Bot::SendMsg($chat_id, "<b><a href='https://es.wikipedia.org/?curid=".$pageId."'>".$title."</a> [<code>".$pageId."</code>]</b>\n<code>".$snippet."...</code>", $message_id);

if ($count > 1) {
    $msg = "<b>".$count." results found</b>";
    $button = array();
    $contador = 0;
    // Create the button
    for ($i=0; $i < $count; $i++) { 
        if ($i % 2 == 0) {
            $button['inline_keyboard'][$contador][0]['text'] = $result[$i]['title'];
            $button['inline_keyboard'][$contador][0]['url'] = 'https://es.wikipedia.org/?curid='.$result[$i]['pageid'];
        } else {
            $button['inline_keyboard'][$contador][1]['text'] = $result[$i]['title'];
            $button['inline_keyboard'][$contador][1]['url'] = 'https://es.wikipedia.org/?curid='.$result[$i]['pageid'];
            $contador++;
        }
    }
    Bot::SendMsg($chat_id, $msg, null, $button);
}

