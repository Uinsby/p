<?php

use App\Models\Bot;
use App\Gate\CurlX;

const API_URL      = 'https://api.ipdata.co/';
const API_KEY      = '2cbf77d05321f9906af26453456a3390fa05695cff1da90a6c509414';
const API_INFO_KEY = 'a93d6474bcb809';
const API_INFO_URL = 'https://ipinfo.io/';

$ip = Bot::GetContent($message, 4, ['send' => true, 'msg' => "<b><i>λ IP lookup ♻️</i>\nFormat:</b> <code>" . $t . "ip " . rand(1, 255) . '.' . rand(1, 255) . '.' . rand(1, 255) .  '.' . rand(1, 255) . "</code>", 'chat_id' => $chat_id, 'msg_id' => $message_id]);

if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6)) {
    // IP no valida ipv4 o ipv6
    Bot::SendMsg($chat_id, "<b>❌ Please provide a valid IP address</b>", $message_id);
} else {
    // Busca la IP en la api

    $url = API_URL . urlencode($ip) . '?api-key=' . API_KEY;

    $datas = json_decode(CurlX::Get($url)->body, true);

    if (isset($datas['message'])) {
        Bot::SendMsg($chat_id, "<b>❌ " . str_replace($ip, '<code>'.$ip.'</code>', $datas['message']) . "</b>", $message_id); // Invalid IP
        exit;
    }

    $url = API_INFO_URL . urlencode($ip) . '?token=' . API_INFO_KEY;
    $fdata = json_decode(CurlX::Get($url)->body, true);

    $d = $datas;
    $th = $d['threat'];

    $txt = "<b>✅ Valid ip ➜ <i>%s</i> %s\nCountry:</b> <i>%s / %s</i>\n<b>Org:</b> <i>%s</i>\n<b>Type:</b> <i>%s</i>\n<b>Time/Zone:</b> <i>%s</i>\n<b>Zip-code</b> <i>%s</i>\n<b>Threat:\n - Known attacker:</b> <i>%s</i>\n <b>- Known abuser:</b> <i>%s</i>\n <b>- Anonymous:</b> <i>%s</i>\n <b>- Is threat:</b> <i>%s</i>\n <b>- Bogon:</b> <i>%s</i>\n <b>- Proxy:</b> <i>%s</i>\n <b>- Tor:</b> <i>%s</i>";
    $txt = sprintf($txt, $ip, $d['emoji_flag'], $d['country_name'], $d['continent_name'], @$d['asn']['name'], ucfirst(@$d['asn']['type']), $fdata['timezone'], $fdata['postal'], BoolString($th['is_known_attacker']), BoolString($th['is_known_abuser']), BoolString($th['is_anonymous']), BoolString($th['is_threat']), BoolString($th['is_bogon']), BoolString($th['is_proxy']), BoolString($th['is_tor']));
    Bot::SendMsg($chat_id, $txt, $message_id);

    $loc = explode(',', $fdata['loc']);
    Bot::sendVenue([
        'chat_id' => $chat_id,
        'latitude' => $loc[0],
		'longitude' => $loc[1],
        'title' => 'IP location ➜ '.$ip,
        'address' => $fdata['city'].' - '.$fdata['region'].' - '.$datas['country_name'].' - '.$datas['continent_code'],
    ]);
}


function BoolString(bool $bool, array $replace = [false => 'False', true => '❌ True']) {
    return $replace[$bool];
}