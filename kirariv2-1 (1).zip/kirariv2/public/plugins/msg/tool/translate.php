<?php

use App\Config\Translate;
use App\Models\Bot;

$query = Bot::GetContent($message, 4);

if (empty($query) && !isset($up['message']['reply_to_message']['text'])) {
    Bot::SendMsg($chat_id, "<b>λ <i>Translate Messages</i>\nFormat:</b> <code>" . $t . "tr lang_code Text</code>", $message_id);
    exit;
}

$lang_co = MultiExlode([' ', "\n"], $query)[0];
$lang_code = explode('|', $lang_co);

$lang_input = $lang_code[0] ?? 'auto';
$lang_output = $lang_code[1] ?? $f['lang'];

if (!isset($lang_code[1])) {
    $lang_input = 'auto';
    $lang_output = $lang_code[0];
}

$lang_output = (empty($lang_output)) ? $f['lang'] : $lang_output;

$textTr = $up['message']['reply_to_message']['caption'] ?? $up['message']['reply_to_message']['text'] ?? trim(substr($query, strlen($lang_co))); // Reply message o message simple

$traduc = Translate::tr($textTr, $lang_input, $lang_output);

if ($traduc->error) {
    Bot::SendMsg($chat_id, '<b>⚠️ <i>' . $traduc->msg . '</i></b>', $message_id);
} else {
    $tr_reply_msg_id = $up["message"]["reply_to_message"]["message_id"] ?? $message_id;
    Bot::SendMsg($chat_id, '<b>Translate (<i>' . $traduc->input->lang . ' to ' . $traduc->output->lang . "</i>)</b>\n\n" . $traduc->output->text, $tr_reply_msg_id);
}
