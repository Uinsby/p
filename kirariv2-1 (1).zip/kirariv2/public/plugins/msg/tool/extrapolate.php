<?php

use App\Models\Bot;
use App\Config\StringUtils;
use App\Gate\{Validate, Bin};

$text = Bot::GetContent($message, 8, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg' => "<b><i>Extrapolate CC</i>\nFormat:</b> <code>" . $t . "extrap " . $cmd['form'] . "</code>",
    'msg_id' => $message_id
]);
    
$cc = StringUtils::CleanString($text, 'cc');
$separa = explode("|", $cc);
$cc = $separa[0];

if (!Validate::luhn($cc)) {
    Bot::SendMsg($chat_id, '<b>Card <i>no pass luhn</i></b>', $message_id); exit;
} if (!Bin::Get($cc)['ok']) {
    Bot::SendMsg($chat_id, '<b>Card bin <i>not found</i></b>', $message_id); exit;
}

$basic = substr($cc, 0, 6) . 'xxxxxxxxxx';
$normal = substr($cc, 0, 10) . 'xxxxxx';

$advanced = substr($cc, 0, 6);
$cc_m = substr($cc, 6, 16);
$cc_m2 = substr($cc_m, 0,3);
$cc_m3 = substr($cc_m, 3,2);
$cc_m4 = substr($cc_m, 6);
$replace = 'x';  
$replace2 = "xx";

$advanced .=  replaceAt($cc_m2, 1, 'x'). replaceAt($cc_m3, 1, 'xx'). replaceAt($cc_m4, 2, 'x');

$msg = sprintf($lang['extrap'], $cc, $basic, $normal, $advanced);
Bot::SendMsg($chat_id, $msg, $message_id);

function replaceAt($cc_m2, $i, $replace){
    return substr_replace($cc_m2,$replace,$i,1); 
};