<?php

use App\Models\Bot;

$hits = [
    'crunchy_roll' => '🈚 CrunchyRoll',
    'acorntv' => 'Acorn TV 🎯',
    'flixole' => '🐂 Flixole',
    'disney' => 'Disney+ ❄️',
    'mail_access' => '📩 Mail Access',
    'fox' => 'Fox 🦊',
    'patreon' => '🎯 Patreon',
    'netflix' => 'Netflix 🍿',
    'vpn' => '🌎 VPN',
    'telecentro' => 'Telecentro ⚜️',
    'xnxx' => '🔥 Xnxx',
];

$create = array();
$contador = 0;
$ic = 0;
foreach ($hits as $i => $item) {
    if ($ic % 2 == 0) {
        $create['inline_keyboard'][$contador][0]['text'] = $item;
        $create['inline_keyboard'][$contador][0]['callback_data'] = 'hit ' . $id . '|' . $i;
    } else {
        $create['inline_keyboard'][$contador][1]['text'] = $item;
        $create['inline_keyboard'][$contador][1]['callback_data'] = 'hit ' . $id . '|' . $i;
        $contador++;
    }
    $ic++;
}
$create['inline_keyboard'][$contador][] = ['text' => 'Close ❌', 'callback_data' => 'finalize|'.$id];

Bot::SendMsg($chat_id, '<b>Chose a hit</b>', $message_id, $create);