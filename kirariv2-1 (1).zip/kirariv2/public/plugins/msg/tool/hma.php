<?php

use App\Gate\CurlX;
use App\Models\Bot;

$query = Bot::GetContent($message, 5, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b><i>λ HMA key checker ♻️</i>\nFormat:</b> <code>".$t."hma ".$cmd['form']."</code>"
]);

$ida = Bot::SendMsg($chat_id, "<i>Checking your key, please wait...</i>", $message_id)['result']['message_id'];

const API_URL = 'https://my-win.avast.com/v1/query/get-exact-application-licenses';
$headers = ['Accept: */*', 'Content-Type: application/x-www-form-urlencoded', 'Host: my-win.avast.com', 'User-Agent: Avast Antivirus', 'Vaar-Header-App-Build-Version: 5655', 'Vaar-Header-App-Id: 00000000-0000-0000-0000-000000000000', 'Vaar-Header-App-IPM-Product: 78', 'Vaar-Header-App-Product-Brand: PRIVAX', 'Vaar-Header-App-Product-Edition: HMA_VPN_CONSUMER', 'Vaar-Header-App-Product-Mode: PAID', 'Vaar-Header-Device-Id: 21ecadfec6538b98af1f92dfb28676a05adadd5abf94fece8723979b5ad9a2c5', 'Vaar-Header-Device-Platform: WIN', 'Vaar-Version: 0'];

$res = CurlX::Post(API_URL, json_encode(['walletKeys' => [$query]]), $headers)->body;

if (empty($res)) {
    Bot::EditMsgTxt($chat_id, $ida, "<b>❌ Invalid key!</b>");
} elseif (strpos($res, 'censes ['.$query.'] do not exist')) {
    Bot::EditMsgTxt($chat_id, $ida, '<b>❌ <i>License ['.$query.'] key do not exist</i></b>');
} else {
    $datas = json_decode($res, true);
    if (!$datas) {
        Bot::EditMsgTxt($chat_id, $ida, "<b>❌ Invalid key!</b>");
        exit;
    }
    $data = $datas[0];
    $mode = $data['mode'];

    Bot::EditMsgTxt($chat_id, $ida, "<b><i>Valid key ✅</i>\nHMA.Key: <code>".$query."</code>\nMode: <code>".$mode."</code>\nProduct: <code>".$data['product']['name']."</code>\nOwner: <code>".$data['order']['owner']['name']."</code>\nMail: <code>".$data['account']['email']."</code>\nChecked by: ".$f['mention']."</b> [<b>".$f['apodo']."</b>]");
}