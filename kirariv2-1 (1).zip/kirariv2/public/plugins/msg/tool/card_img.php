<?php

use App\Models\Bot;
use App\Gate\Card;
use App\Faker\Name;

const DIR_IMG = './files/temp';
$temp_file = DIR_IMG.'/'.uniqid('card_').'.png';

$query = Bot::GetContent($message, 6, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b>Card img gen\nFormat:</b> <code>" . $t . "card " . $cmd['form'] . "</code>",
]); 

$cc = Card::SetCard($query);

if (!$cc['ok']) {
    Bot::SendMsg($chat_id, "<b>Card img gen ⚠️\n<u>Format:</u></b> <code>" . $t . "card " . $cmd['form'] . "</code>", $message_id);
    exit;
}

if ($cc['data']['valid'] == 0) {
    $txt = "<b>⚠️ <u>All cards are invalid</u></b>\n\n";
    foreach ($cc['cc']['invalid'] as $value) {
        $txt .= "<b>⌧ Cc:</b> <code>".implode('|', $value['cc'])."</code>\n<b>⌧ Reason:</b> <i>".$value['reason']['msg']."</i>\n\n";
    }
    Bot::SendMsg($chat_id, $txt, $message_id);
    exit;
}

unset($cc['cc']['invalid']);
$cc = $cc['cc']['valid'][0]['cc'];

$first = (int) $cc[0][0];
$brand = match($first) {4 => 'VISA', 5 => 'MASTERCARD', 3 => 'AMERICAN+EXPRESS', 6 => 'DISCOVER', default => 'VISA'};

$names = Name::firstName() . ' ' . Name::lastName();

$tarjeta = http_build_query(['numtarjeta' => $cc[0], 'fv' => $cc[1] . '/' . $cc[2], 'nombreth' => $names, 'tj' => $brand]);
const API_URL = 'https://herramientas-online.com/showimage.php?';

file_put_contents($temp_file, file_get_contents(API_URL . $tarjeta));

$a = Bot::Photo($chat_id, $temp_file, "<b>Credit card:</b> <code>" . $query . "</code>\n\n<b>Photo by @Kirarichk</b>", $message_id);

if (!$a['ok']) {
    Bot::SendMsg($chat_id, '<b>File to send img:</b> <i>'.$a['description'].'</i>', $message_id);
}

unlink($temp_file);