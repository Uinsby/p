<?php // CMD info

use App\Config\StringUtils;
use App\Models\{Bot, Cmd};

$query = Bot::GetContent($message, 7, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b>λ <i>Command info</i>\nFormat:</b> <code>" . $t . "cinfo " . $cmd['form'] . "</code>",
]);

/** * Safe string */
$query = StringUtils::RemoveNoAlpha($query);
$ccmd = Cmd::Get($query);

if (!$ccmd['ok']) {
    // Not found
    Bot::SendMsg($chat_id, '<b>Command <i>'.$query.'</i> not found, type <i>'.$t.'cmds</i> to know all commands</b>', $message_id);
    exit;
}

$em = function (bool $var) {
    return $var ? 'True' : 'False';
};
// Basic info (all users)
$txt = '<b>Command:</b> <code>'.$ccmd['cmd'].'</code>' . "\n<i>Name:</i> " . $ccmd['name'] . "\n<i>Format:</i> <code>".$t.$ccmd['cmd']."</code>\n<i>Last review:</i> " . date('d/m/Y H:i:s', $ccmd['review']);
if ($f['staff'] != 'user') {
    // Complet info (staff)
    $txt .= "\n<i>Status:</i> ".$em($ccmd['status'])."\n<i>Test:</i> ".$em($ccmd['test']) . PHP_EOL . '<i>Access:</i> ' . $ccmd['access'] . "\n<i>Type:</i> " . $ccmd['type'] . "\n<i>Route:</i> " . $ccmd['route'] . "\n<i>Description:</i> " . $ccmd['msg'];
}
Bot::SendMsg($chat_id, $txt, $message_id);