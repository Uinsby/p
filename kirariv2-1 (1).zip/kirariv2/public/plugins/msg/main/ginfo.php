<?php 
// Group info
use App\Models\{Chat, Bot};

if ($type_chat == 'private') {
    Bot::SendMsg($chat_id, '<b>Only use this command in groups</b>', $message_id);
    exit;
}

$ginfo = Chat::GetGroup($chat_id);
$title = $up['message']['chat']['title'] ?? 'Info';

$txt = "<b>Group ".$title."\n\nId: <code>".$chat_id."</code>\nType:</b> <i>".ucfirst($ginfo['type'])."</i>\n<b>Members:</b> ".$ginfo['members']."\n<b>Expired:</b> <i>".SecondsToTime($ginfo['finish_time']-time())."</i>";

Bot::SendMsg($chat_id, $txt);