<?php

use App\Gate\CurlX;
use App\Models\Bot;

if ($f['staff'] != 'owner') {
  Bot::SendMsg($chat_id, 'No allowed.', $message_id); exit;
}

$for = Bot::GetContent($message, 6);

if (!isset($up['message']['reply_to_message']['text']) || empty($for)) {
    Bot::SendMsg($chat_id, 'Please, specify a type and reply to message.', $message_id); exit;
}

$data = [
    'users' => $for,
    'chat_id' => $chat_id,
    'from_msg_id' => $message_id,
    'msg_id' => $up['message']['reply_to_message']['message_id']
];

CurlX::Post('https://jacksonv-1603.ml/kirari/public/apis/forward.php', json_encode($data));