<?php 

use App\Models\Bot;

$query = (bool) Bot::GetContent($message, 9);

$dir = '../src/logs/';
$files = scandir($dir);

foreach ($files as $i) {
    if (file_exists($dir.$i) && !is_dir($dir.$i)) {
        Bot::SendMsg($chat_id, 'Sending file, please wait...', $message_id);
        Bot::sendDocument([
            'chat_id' => $id,
            'document' => new CURLFile(realpath($dir.$i), 'text/plain', 'log_'.uniqid($id).'.txt'),
            'protect_content' => true,
            'reply_markup' => json_encode(['inline_keyboard' => [[['text' => 'Delete', 'callback_data' => 'finalize|'.$id]]]])
        ]);
        if ($query) unlink($dir.$i);
        exit;
    }
}

Bot::SendMsg($chat_id, 'No logs found', $message_id);