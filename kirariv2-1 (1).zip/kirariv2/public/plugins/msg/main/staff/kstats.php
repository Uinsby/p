<?php 

use App\Db\Query;
use App\Models\{Bot, User};

$stats = [
    'user' => [ /**Users*/
        'premium' => Query::Sql("SELECT COUNT(*) FROM users WHERE status = :sta", ['sta' => 'premium'])['datas']['COUNT(*)'],
        'free' => Query::Sql("SELECT COUNT(*) FROM users WHERE status != :sta", ['sta' => 'premium'])['datas']['COUNT(*)'],
        'muted' => Query::Sql("SELECT COUNT(*) FROM users WHERE is_muted = :muted", ['muted' => true])['datas']['COUNT(*)'],
        'banned' => Query::Sql("SELECT COUNT(*) FROM users WHERE is_banned = :banned", ['banned' => true])['datas']['COUNT(*)'],
    ],
    'bins' => [
        'banned' => Query::Sql("SELECT COUNT(*) FROM bins WHERE banned = :banned", ['banned' => true])['datas']['COUNT(*)'],
        'vbv_msc' => Query::Sql("SELECT COUNT(*) FROM bins WHERE vbv_msc = :vbv_msc", ['vbv_msc' => true])['datas']['COUNT(*)'],
    ],
    'groups' => [
        'free' => Query::Sql("SELECT COUNT(*) FROM groups WHERE type = :typ", ['typ' => 'free'])['datas']['COUNT(*)'],
        'premium' => Query::Sql("SELECT COUNT(*) FROM groups WHERE type = :typ", ['typ' => 'premium'])['datas']['COUNT(*)'],
        'unauth' => Query::Sql("SELECT COUNT(*) FROM groups WHERE type = :typ", ['typ' => 'unauth'])['datas']['COUNT(*)'],
    ],
    'extras' => [
        'all' => Query::Sql("SELECT COUNT(*) FROM extras")['datas']['COUNT(*)']
    ],
    'gates' => [
        'free' => Query::Sql("SELECT COUNT(*) FROM cmds WHERE type = :typ AND access = :access", ['typ' => 'gates', ':access' => 'free'])['datas']['COUNT(*)'],
        'premium' => Query::Sql("SELECT COUNT(*) FROM cmds WHERE type = :typ AND access = :access", ['typ' => 'gates', ':access' => 'premium'])['datas']['COUNT(*)'],
        'off' => Query::Sql("SELECT COUNT(*) FROM cmds WHERE type = :typ AND status = :status", ['typ' => 'gates', ':status' => 0])['datas']['COUNT(*)'],
    ]
];

$txt = "<b><u>Stats</u> @".bot_username."

Users:</b>
    - <i>Premium:</i> <b>".$stats['user']['premium']."</b>
    - <i>Free:</i> <b>".$stats['user']['free']."</b>
    - <i>Muted:</i> <b>".$stats['user']['muted']."</b>
    - <i>Banned:</i> <b>".$stats['user']['banned']."</b>

<b>Bins:</b>
    - <i>Banned:</i> <b>".$stats['bins']['banned']."</b>
    - <i>VBV MSC:</i> <b>".$stats['bins']['vbv_msc']."</b>

<b>Groups:</b>
    - <i>Free:</i> <b>".$stats['groups']['free']."</b>
    - <i>Premium:</i> <b>".$stats['groups']['premium']."</b>
    - <i>Unauth:</i> <b>".$stats['groups']['unauth']."</b>

<b>Extras:</b>
    - <i>All:</i> <b>".$stats['extras']['all']."</b>
    
<b>Gates:</b>
    - <i>Free:</i> <b>".$stats['gates']['free']."</b>
    - <i>Premium:</i> <b>".$stats['gates']['premium']."</b>
    - <i>Off:</i> <b>".$stats['gates']['off']."</b>";


Bot::SendMsg($chat_id, $txt, $message_id, [
    'inline_keyboard' => [
        [['text' => User::GetTook(true)."'s | Channel", 'url' => 'https://t.me/Kirarichk']]
    ]
]);