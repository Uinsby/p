<?php 
use App\Models\{Bot, User};
use App\Config\{StringUtils as Utils, ErrorLog as Logger};

if (!in_array($f['staff'], ['owner', 'admin', 'mod'])) {
    Bot::SendMsg($chat_id, '<b>No allowed</b>', $message_id);
    exit;
}

$query = Bot::GetContent($message, 7);

if (empty($query) && !isset($mg['reply_to_message'])) {
    Bot::SendMsg($chat_id, "<b>λ <i>Warn users</i>\nFormat:</b> <code>" . $t . "kwarn " . $cmd['form'] . "</code>", $message_id);
    exit;
}

$data = MultiExlode(['|', ' '], $query);

if (isset($mg['reply_to_message']['from']['id'])) {
    $idac = $mg['reply_to_message']['from']['id'];
} else {
    $idac = $data[0];
    unset($data[0]);
}

$reason = trim(implode(' ', $data));

$u = SearchUser($idac);

if ($u === false) {
    Bot::SendMsg($chat_id, '<b><i>Invalid input</i></b>', $message_id); exit;
} elseif (!$u['ok']) {
    Bot::SendMsg($chat_id, '<b>User not found! (<i>'.$idac.'</i>)</b>', $message_id); exit;
} elseif ($u['id'] == $id) {
    Bot::SendMsg($chat_id, '<i>Are you sure?</i>', $message_id); exit;
}

// Despues de buscar al usuario, se añade esto
if (empty($reason)) {
    $reason = $u['msg'] ?? '';
}

$kwarn = User::AddWarn($u, 1);

if (!$kwarn) {
    Bot::SendMsg($chat_id, 'Fail to add warn', $message_id);
    Logger::ReportToChannel('Fail to add warn to ' . $u['mention']);
} else {
    Bot::SendMsg($chat_id, '<b>Warn added!</b>', $message_id);
    Bot::SendMsg($u['id'], '<b>You have been warned!'.PHP_EOL.'Reason: <i>'.$reason.'</i>'.PHP_EOL.'Total warns:</b> <i>'.($u['warns']+1).'</i>', $message_id);
    Logger::ReportToChannel('#Warn added to ' . $u['mention'] . ' by ' . $f['mention'] . ' for ' . $reason);
}