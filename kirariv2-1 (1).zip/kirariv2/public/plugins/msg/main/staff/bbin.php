<?php 
use App\Models\Bot;
use App\Config\ErrorLog as Logger;
use App\Gate\Bin;

if (!in_array($f['staff'], ['owner', 'admin', 'mod'])) {
    Bot::SendMsg($chat_id, '<b>No allowed</b>', $message_id);
    exit;
}

$query = Bot::GetContent($message, 6, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b>λ <i>Ban and Unban any bin</i>\nFormat:</b> <code>" . $t . "bbin " . $cmd['form'] . "</code>",
]);

$data = MultiExlode(['|', ' '], strtolower($query));

if (count($data) != 2) {
    Bot::SendMsg($chat_id, "<b>⚠️ <i>Ban and Unban any bin</i>\nFormat:</b> <code>" . $t . "bbin " . $cmd['form'] . "</code>", $message_id);
    exit;
}

if (empty($data[1]) || $data[1] == null || $data[1] == 'false') {
    $data[1] = false;
} else {
    $data[1] = true;
}
$bstr = ($data[1]) ? 'ban' : 'unban';
$fim = Bin::Get($data[0]);

if (!$fim['ok']) {
    Bot::SendMsg($chat_id, "<b><i>Bin not found</i></b>", $message_id); exit;
} elseif ($fim['banned'] == $data[1]) {
    Bot::SendMsg($chat_id, "<b><i>Bin already " . $bstr . "ed</i></b>", $message_id); exit;
}

$bbin = Bin::BanUnban($fim['bin'], $data[1]);


if (!$bbin['ok']) {
    Bot::SendMsg($chat_id, "<b><i>Fail to ".$bstr."ed bin</i></b>", $message_id); exit;
}

Bot::SendMsg($chat_id, "<b><i>Bin ".$bstr."ed</i> (".$fim['bin'].")</b>", $message_id, [
    'inline_keyboard' => [
        [['text' => 'Bin info', 'callback_data' => 'bin '.$fim['bin']]],
    ]
]);

Logger::ReportToChannel('[bin] ['.$fim['bin'].'] '.$bstr.'ed by '.$f['mention']);
exit;