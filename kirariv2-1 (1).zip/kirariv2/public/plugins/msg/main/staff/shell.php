<?php 
use App\Models\{Bot, User};
use App\Config\{StringUtils as Utils, ErrorLog as Logger};

if ($f['staff'] != 'owner') {
    Bot::SendMsg($chat_id, '<b>No allowed</b>', $message_id);
    exit;
}

$query = Bot::GetContent($message, 7, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg' => "<b>Execute comands in cmd\nFormat:</b> <code>".$t.'shell '.$cmd['form']."</code>",
    'msg_id' => $message_id
]);


$ouput = shell_exec(escapeshellcmd($query)) ?? 'Null';

if (strlen($ouput) < 3000) {
    // Send message text
    Bot::SendMsg($chat_id, "<b>Cmd:</b> <i>" . $query . "</i>\n\n<code>" . Utils::QuitHtml($ouput) . '</code>', $message_id);
} else {
    // Send result in .txt file

    $file_name = './files/temp/' . $f['tmp_file'];
    file_put_contents($file_name, $ouput);
    Bot::sendDocument([
        'chat_id' => $chat_id,
        'reply_to_message_id' => $message_id,
        'caption' => '<b>CMD:</b> <code>' . $query . '</code>',
        'parse_mode' => 'HTML',
        'document' => new CURLFile(realpath($file_name))
    ]);
    unlink($file_name);
}