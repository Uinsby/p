<?php 
use App\Models\{Bot, User};
use App\Config\{StringUtils as Utils, ErrorLog as Logger};

if ($f['staff'] != 'staff') {
    Bot::SendMsg($chat_id, '<b>No allowed</b>', $message_id);
    exit;
}