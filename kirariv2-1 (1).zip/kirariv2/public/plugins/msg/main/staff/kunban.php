<?php 

use App\Models\{Bot, User};
use App\Config\{ErrorLog as Logger};

if (!in_array($f['staff'], ['owner', 'admin', 'mod'])) {
    Bot::SendMsg($chat_id, '<b>No allowed</b>', $message_id);
    exit;
}

$query = Bot::GetContent($message, 7);

if (empty($query) && !isset($mg['reply_to_message'])) {
    Bot::SendMsg($chat_id, "<b>λ <i>UnBan users</i>\nFormat:</b> <code>" . $t . "kunban " . $cmd['form'] . "</code>", $message_id);
    exit;
}

$data = MultiExlode(['|', ' '], $query);

if (isset($mg['reply_to_message']['from']['id'])) {
    $idac = $mg['reply_to_message']['from']['id'];
} else {
    $idac = $data[0];
    unset($data[0]);
}

$reason = trim(implode(' ', $data));

$u = SearchUser($idac);

if ($u === false) {
    Bot::SendMsg($chat_id, '<b><i>Invalid input</i></b>', $message_id); exit;
} elseif (!$u['ok']) {
    Bot::SendMsg($chat_id, '<b>User not found! (<i>'.$idac.'</i>)</b>', $message_id); exit;
} elseif (!$u['is_banned']) {
    Bot::SendMsg($chat_id, '<b>User not banned</b> <i>('.$u['mention'].')</i>', $message_id); exit;
} elseif ($u['id'] == $id) {
    Bot::SendMsg($chat_id, '<i>Are you sure?</i>', $message_id); exit;
}
// Despues de buscar al usuario, se añade esto
if (empty($reason)) {
    $reason = $u['msg'] ?? '';
}

$bban = User::UpBan(false, $u['id'], $reason);
if (!$bban) {
    Bot::SendMsg($chat_id, '<b>Fail to unban user</b>', $message_id);
    Logger::ReportToChannel('[unban] [de:'.$id.'] [a:'.$u['id'].'] Fail to unban user');
} else {
    Bot::SendMsg($chat_id, '<b>User unbanned</b> <i>('.$u['mention'].')</i>', $message_id);
    Bot::SendMsg($u['id'], '<b>You have been unbanned</b> <i>('.$u['mention'].')</i>');
    Logger::ReportToChannel('[unban] [de:'.$id.'] [a:'.$u['id'].'] User unbanned');
}
