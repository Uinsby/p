<?php 
use App\Models\{Bot, User};
use App\Config\{StringUtils as Utils, ErrorLog as Logger};

if (!in_array($f['staff'], ['owner', 'seller'])) {
    Bot::SendMsg($chat_id, '<b>No allowed</b>', $message_id);
    exit;
}

$query = Bot::GetContent($message, 5, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b>λ <i>Add credits to users (".ucfirst($f['staff']).")</i>\nFormat:</b> <code>" . $t . "add " . $cmd['form'] . "</code>",
]);

$data = MultiExlode(['|', ' '], $query);

if (isset($up['message']['reply_to_message']['from']['id'])) {
    $idac = $up['message']['reply_to_message']['from']['id'];
} else {
    $idac = $data[0];
    unset($data[0]);
}
$crd = (int) Utils::RemoveStrings(implode('', $data));

if (empty($idac) || empty($crd)) {
    Bot::SendMsg($chat_id, '<b><i>Empty fields</i></b>', $message_id); exit;
}

$a = SearchUser($idac);

if ($a === false || !$a['ok']) {
    Bot::SendMsg($chat_id, '<b>User not found!</b>', $message_id); exit;
} elseif ($a['is_muted'] || $a['is_banned']) {
    Bot::SendMsg($chat_id, '<b>User is muted or banned!</b>', $message_id); exit;
}

$newcrd = $crd + $a['creditos']; // new credits, add old credits
$expirecrd = 86400 * 45; // 45 days
$a['credit_expired'] = ($a['credit_expired'] == '0' || $a['credit_expired'] < time()) ? time() : $a['credit_expired']; // if expired, set new expired
$newexpirecrd = $a['credit_expired'] + $expirecrd; // new expired

$u = User::Update($a['id'], $a['status'], $a['staff'], $newcrd, $a['save_live'], $a['member_expired'], $newexpirecrd, $a['apodo'], $a['antispam']);

if (!$u['ok']) {
    Logger::ReportToChannel('[add] ['.$f['staff'].'('.$f['id'].')] Fail to add credits to ' . $idac);
    Bot::SendMsg($chat_id, '<b>Fail to add credits to user, or no exists!</b>', $message_id); exit;
} else {
    Logger::ReportToChannel('[add] ['.$f['staff'].'('.$f['id'].')] Added ' . $crd . ' credits to ' . $idac);
    Bot::SendMsg($chat_id, '<b>Added ' . $crd . ' credits to user!</b>', $message_id);
    Bot::SendMsg($a['id'], '<b>Added ' . $crd . ' credits to you!</b>'.PHP_EOL.'<i>Note:</i> Expire in 45 days');
}
