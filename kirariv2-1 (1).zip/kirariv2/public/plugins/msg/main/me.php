<?php

use App\Config\{StringUtils as Utils, Flag};
use App\Models\{Bot, User};

$member_expired = 'No membership';
if ($f['member_expired'] > 0) {
    $member_expired = Utils::TimeToString($f['member_expired']-time(), '%d days, %h hours and %m minutes');
}
$last_check = 'Never';
if ($f['last_check'] > 0){
    $last_check = date('D, j M Y', $f['last_check']);
}

$auth = $f['is_private'] ? 'Yes' : 'No';
$_live = $f['save_live'] ? 'Yes' : 'No';
$_ref = ($f['ref_of'] != '0') ? User::Mention('', $f['ref_of'], $f['ref_of']) : 'No';

$me = sprintf($lang['me'], $id, $f['permalink'], $f['apodo'], ucfirst($f['status']), ucfirst($f['staff']), $f['username'], $f['creditos'], $member_expired, $f['warns'], $auth, $f['antispam']."'", $last_check, ucfirst($f['lang']) . ' ' . Flag::Emoji($f['lang']), $_live, $_ref);

Bot::SendMsg($chat_id, $me, $message_id, ['inline_keyboard' => [
    [['text' => EmojiBool(!$f['save_live']) . ' Change save live', 'callback_data' => 'me ' . $id . '|live|'.(int) $f['save_live'] ],
    ['text' => 'Lang ('.Flag::Emoji($f['lang']).')', 'callback_data' => 'me ' . $id . '|lang']]
]]);

function EmojiBool(bool $bool) {
    return $bool ? '✅' : '❌';
}