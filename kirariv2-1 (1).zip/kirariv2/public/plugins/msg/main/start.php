<?php

use App\Models\User;
use App\Models\Bot;
use App\Config\Keys;
use App\Db\Query;
use App\Config\Exchange;

$Greeting = User::GetGreeting($f['lang'], $f['first_name']);
$button = ['inline_keyboard' => [[['text' => 'Cmds 💻', 'callback_data' => 'cmds '.$id.'|']], [['text' => 'Add me to a group', 'url' => 'http://t.me/'.bot_username.'?startgroup=true']]], 'resize_keyboard' => true];

$button_cmds = [
  'inline_keyboard' => [
    [
      ['text' => 'Tools 🌀', 'callback_data' => 'cmds '.$id.'|tools|0'],
      ['text' => 'Gates 💳', 'callback_data' => 'cmds '.$id.'|gates'],
      ['text' => 'Others ⚙️', 'callback_data' => 'cmds '.$id.'|others|0']
    ], [
      ['text' => 'Extras ', 'callback_data' => 'cmds '.$id.'|extras|0'],
      ['text' => 'Finish', 'callback_data' => 'finalize|'.$id]
    ]
  ]
];

$action = strtolower (Bot::GetContent($message, 7));

if ($type_chat == 'private' && $t == '/' && $action != null) {
  # telegram bot deep-linking
  $data = explode('-', $action);
  
  if (count($data) < 2) {
    Bot::SendMsg($chat_id, $Greeting, $message_id, $button);
  } elseif($data[0] == 'ref' && $data[1] != $id && is_numeric($data[1])) {
    # /start ref-userid
    $data_ref = User::GetUser($data[1], 'tg_id', false);

    if ($data_ref['ok'] == false || $data_ref['is_private'] == false || $data_ref['is_banned'] == true) {
      // Unknow user
      Bot::SendMsg($chat_id, '<b>⚠️ Invalid ref link</b>', $message_id);
    } elseif ($data_ref['n_ref'] > 20) {
      // Max number of ref
      Bot::SendMsg($chat_id, $Greeting, $message_id, $button);
    } elseif($f['ref_of'] != 0) {
      // User is a ref from another user
      Bot::SendMsg($chat_id, '<b>⚠️ You are already a referral</b>', $message_id);
    } else {
      // Valid link
      $credita1 = $f['creditos'] + 0.5; // Creditos para el usuario que uso el link de referido
      $credita2 = $data_ref['creditos'] + 1; // Creditos para el usuario que dío el link de referido
      $ref_number = $f['n_ref'] + 1;

      $expire = 86400 * 7; // 7 days
      $credit_expired1 = ($data_ref['credit_expired'] == 0) ? time() + $expire : $data_ref['credit_expired'] + $expire;
      $credit_expired2 = ($f['credit_expired'] == 0) ? time() + $expire : $f['credit_expired'] + $expire;

      $res1 = Query::Sql("UPDATE users SET creditos=:credt, n_ref=:n_ref, credit_expired=:credt_expire WHERE tg_id=:id", ['credt' => $credita2, 'n_ref' => $f['n_ref'] + 1, 'credt_expire' => $credit_expired1,'id' => $data[1]])['ok']; // Usuario que dio el link de referido
      $res2 = Query::Sql("UPDATE users SET creditos=:credt, ref_of=:ref_of, credit_expired=:credt_expire WHERE tg_id=:id", ['credt' => $credita1, 'ref_of' => $data[1], 'credt_expire' => $credit_expired2, 'id' => $id])['ok']; // Usuario que uso el link de referido

      if ($res1 && $res2) {
        // Success
        Bot::SendMsg($chat_id, '<b>✅ Referral link used</b>, Now you are referred from <i>'.$data_ref['first_name'].'</i>', $message_id);
        Bot::SendMsg($chat_id, '+0.5 credits');
        Bot::SendMsg($data[1], 'Ref bonus: +1 credit');
      } else {
        // Unknow error
        Bot::SendMsg($chat_id, '<b>⚠️ Unknown error, if the error persists contact a bot admin</b>', $message_id);
      }

    }

  } elseif($data[0] == 'key' && count($data) == 5) {
    # e.g.: /start key-Kirari-996202950-Un3IFo-GizTXvs
    $key = Bot::GetContent($action, 4);
    $data = Keys::Claim($key, $f);
    if (!$data['ok']) {
      Bot::SendMsg($chat_id, '<i>'.$data['msg'].'</i>', $message_id);
    }
    
  }elseif ($data[0] == 'premium' || $data[0] == 'access') {
    $cr = ['100' => $_ENV['CR_100'], '200' => $_ENV['CR_200'], '500' => $_ENV['CR_500']];

    $prices = Exchange::Prices($cr);
    Bot::SendMsg($chat_id, $prices, $message_id);
  } else {
    Bot::SendMsg($chat_id, $Greeting, $message_id, $button_cmds);
  }
} else {
  # Send default message
  Bot::SendMsg($chat_id, $Greeting, $message_id, $button);
}
