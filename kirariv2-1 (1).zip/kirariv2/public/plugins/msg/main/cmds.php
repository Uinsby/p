<?php

use App\Models\Bot;

$inline_keyboard = [
    [
        ['text' => 'Tools 🌀', 'callback_data' => 'cmds ' . $id . '|tools|0'],
        ['text' => 'Gates 💳', 'callback_data' => 'cmds ' . $id . '|gates'],
        ['text' => 'Others ⚙️', 'callback_data' => 'cmds ' . $id . '|others|0'],
    ], [
        ['text' => 'Channel', 'url' => 'https://t.me/Kirarichk'],
        ['text' => 'Extras 🧰', 'callback_data' => 'cmds ' . $id . '|extras|0'],
        ['text' => 'Finish', 'callback_data' => 'finalize|' . $id],
    ],
];

$level_staff = strtolower($f['staff']);

switch ($level_staff) {
    case 'owner':$inline_keyboard[2][0] = ['text' => 'Cmds Staff 🔏', 'callback_data' => 'panel ' . $id . '|owner'];
        break;
    case 'admin':$inline_keyboard[2][0] = ['text' => 'Cmds Staff 🔏', 'callback_data' => 'panel ' . $id . '|admin'];
        break;
    case 'seller':$inline_keyboard[2][0] = ['text' => 'Cmds Staff 🔏', 'callback_data' => 'panel ' . $id . '|seller'];
        break;
    case 'helper':$inline_keyboard[2][0] = ['text' => 'Cmds Staff 🔏', 'callback_data' => 'panel ' . $id . '|helper'];
        break;
    case 'mod':$inline_keyboard[2][0] = ['text' => 'Cmds Staff 🔏', 'callback_data' => 'panel ' . $id . '|mod'];
        break;
}

Bot::SendMsg($chat_id, 'Hi!, press one of the button below', $message_id, ['inline_keyboard' => $inline_keyboard]);
