<?php

use App\Models\Bot;

$id = Bot::GetContent($message, 6);

if (empty($id)) {
    $id = $up["message"]["reply_to_message"]["from"]["id"] ?? $up['message']['from']['id'];
}
$datas = SearchUser($id);

if (!$datas['ok']) {
    Bot::SendMsg($chat_id, '<b>Not found ➜</b> <code>'.$id.'</code>', $message_id);
    exit;
}

$username = $datas['username']??'Does not have';

$txt = sprintf($lang['info'], $datas['id'], $datas['permalink'], ucfirst($datas['apodo']), $username, ucfirst($datas['status']));
Bot::SendMsg($chat_id, $txt, $message_id);