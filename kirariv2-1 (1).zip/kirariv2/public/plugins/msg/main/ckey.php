<?php

use App\Config\ErrorLog;
use App\Config\Keys;
use App\Models\Bot;

if (!in_array($f['staff'], ['owner', 'seller'])) {
    Bot::SendMsg($chat_id, '<b>No allowed</b>', $message_id);
    exit;
}

$query = Bot::GetContent($message, 6, [
    'send' => true,
    'chat_id' => $chat_id,
    'msg_id' => $message_id,
    'msg' => "<b>λ <i>Create key premium</i>\nFormat:</b> <code>" . $t . "expkey " . $cmd['form'] . "</code>",
]);

$options = ['premium', 'free', 'not_change'];

$data = MultiExlode(['|', ' '], $query);

if (count($data) < 3) {
    // Faltan datos
    Bot::SendMsg($chat_id, "<b>λ <i>Create key premium</i> (".count($data).")⚠️\nFormat:</b> <code>" . $t . "expkey " . $cmd['form'] . "</code>", $message_id);
} elseif (!is_numeric($data[0])) {
    // Invalid number
    Bot::SendMsg($chat_id, "<b>⚠️ Invalid format\nReason:</b> <i>Data N must be a number</i> (".$data[0].")", $message_id);
} elseif (in_array($data[1], $options) == false) {
    // Invalid status key
    Bot::SendMsg($chat_id, "⚠️ <b><i>Invalid type</i> (<i>".$data[1]."</i>)\nAllowed types:</b> <code>".implode(', ', $options).'</code>', $message_id);
} else {
    
    $key = Keys::genKey($id);
    $expire = days_to_seconds($data[2]);
    $credits = @$data[3] ?? 0;

    Keys::Save($key, $data[1], $expire, $credits, $data[0]);

    $txt = "<b>Key:</b> <a href='https://t.me/".bot_username."?start=key-".$key."'>".$key."</a>\n<b>Type:</b> <i>".$data[1]."</i>\n<b>Credits:</b> ".$credits."\n<b>How many can use it:</b> ".$data[0]."\n<b>Duration:</b> <i>".SecondsToTime($expire)."</i>\n<b>Created by:</b> ".$f['mention'];  
    Bot::SendMsg($chat_id, $txt, $message_id, null, 'html', true);
    ErrorLog::ReportToChannel($txt);
    exit;
}

/**
 * Convertir un día a segundos
 */
function days_to_seconds(int|float|string $days)
{
    return $days * 86400;
}
